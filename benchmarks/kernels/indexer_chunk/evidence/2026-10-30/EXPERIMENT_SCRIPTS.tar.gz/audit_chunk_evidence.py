import json,hashlib,re,ast
from pathlib import Path
p=Path('/home/bopang/cg-project/design/indexer-chunk-default-20261030-v2');out=p/'review'
expected='f96b1e72533bc79d154f245d0ffc62817fd99fd2987e97b8e4e63a14dbe02f92';audit={}
for stage in ['', 'refinement','tail_policy','tail_policy/balanced','order_ab','order_ab/original','fallback']:
 root=p/stage;count=0;complete=0;proofs=0;dynamic=0;callers=set();failed=[]
 for f in (root/'results').glob('*/IDENTITY.json'):
  d=json.loads(f.read_text());assert d['native_sha']==expected;callers.add(d['caller_sha']);count+=1
  r=f.parent/'RESULT.json'
  if not r.exists():failed.append(f.parent.name);continue
  result=json.loads(r.read_text());assert result['status']=='complete',str(r);complete+=1
  for z in f.parent.glob('proof_*.json'):
   x=json.loads(z.read_text());assert x.get('upcasts',0)==0;assert x.get('replay_host_unchanged',True);proofs+=1;dynamic+=bool(x.get('dynamic_shrink_grow'))
 audit[stage or 'coarse']=dict(complete_cases=complete,identity_count=count,proof_count=proofs,dynamic_replay_proofs=dynamic,caller_hashes=sorted(callers),failed_or_incomplete_cases=failed)
assert audit['coarse']['complete_cases']==21
assert audit['refinement']['complete_cases']>=12
# Current final production bytes must match the measured refinement source.
wt=Path('/home/bopang/cg-project/wt-indexer-chunk-bf16')
for name in ['vllm/envs.py','vllm/model_executor/layers/sparse_attn_indexer.py']:
 a=(wt/name).read_bytes();b=(p/'refinement/runtime'/name).read_bytes();assert ast.dump(ast.parse(a))==ast.dump(ast.parse(b)),name
 audit.setdefault('final_source_identity',{})[name]=dict(byte_identical=a==b,AST_identical=True,final_sha256=hashlib.sha256(a).hexdigest(),measured_sha256=hashlib.sha256(b).hexdigest(),note='envs.py differs only by removing the obsolete Opt-in wording in a comment' if a!=b else '')
for stage,job in [('e2e','41456'),('e2e_v41','41468'),('pd','41481')]:
 arms={};stats={}
 for arm in ['0_A','1_B','2_A']:
  base=p/stage/'results'/f'{job}_{arm}';folder=base/'decode' if stage=='pd' else base
  driver=json.loads((base/'DRIVER.json').read_text());assert driver['complete']
  d=json.loads((folder/'RESULT.json').read_text());assert d['protocol_pass'];assert d['correct']==d['count'];assert arm!='1_B' or d['actual_chunk_replay_pass']
  arms[arm]=d;stats[arm]={k:d[k] for k in ['correct','count','protocol_pass']};stats[arm]['actual_chunk_replay_pass']=d['actual_chunk_replay_pass'] if arm=='1_B' else None
  if stage=='pd':
   metrics=(folder/'client/after_c32.decode.metrics.txt').read_text();before=(folder/'client/before.decode.metrics.txt').read_text()
   pat=r'^vllm:nixl_bytes_transferred_sum\{[^\n]+\} ([\deE+.]+)$'
   n=lambda s:sum(float(v) for v in re.findall(pat,s,re.M))
   delta=n(metrics)-n(before);assert delta>0;stats[arm]['NIXL_transferred_bytes']=delta
 comparisons=[]
 for a,b in [('0_A','1_B'),('0_A','2_A'),('1_B','2_A')]:
  aa={x['case_id']:x for x in arms[a]['answers']};bb={x['case_id']:x for x in arms[b]['answers']};assert aa.keys()==bb.keys()
  comparisons.append(dict(a=a,b=b,count=len(aa),token_string_sequences_equal=sum(aa[k]['token_strings']==bb[k]['token_strings'] for k in aa)))
 value=dict(job=job,arms=stats,comparisons=comparisons);(p/stage/'FINAL_SUMMARY.json').write_text(json.dumps(value,indent=2)+'\n');audit[stage]=value
(out/'EVIDENCE_AUDIT.json').write_text(json.dumps(audit,indent=2)+'\n');print(json.dumps(audit,indent=2))
