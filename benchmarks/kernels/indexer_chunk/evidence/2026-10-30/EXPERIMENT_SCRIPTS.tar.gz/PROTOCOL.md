# Decode chunk default selection, v2

## Decision
Choose a configurable BF16 logits payload budget that reduces peak memory while avoiding substantial regression on common model-shaped decode. Do not claim a universal optimum or select from only one stress shape. Sweep disabled, 512 MiB, 1, 2, 3, 4, 6, 8 GiB; refine only where the Pareto boundary warrants it. Preserve all raw records and previous results.

## Baseline and scope
Both arms use the same combined cooperative/persistent BF16 implementation, unchanged auto dispatch and real DeepGEMM. Both arms also include the isolated two-expression size_t addressing correction: otherwise the large unchunked eager baseline can read the wrong row. This correction is an explicit dependency, not a chunk performance benefit. Native identity is asserted in every process. The original and corrected source/artifact hashes are retained in the preceding overflow_fix package.

Inputs are synthetic model-shaped MXFP4 Q/K with nonuniform scales and shuffled paged cache, not a real serving traffic distribution. C1 includes candidate generation; C2 and C4 are dense indexers. C4 topk1024 covers the cached V4-Pro shape. Model-level followup uses actual weights, and must distinguish synthetic-token/zero-KV forward results from real-text serving evaluation.

## Correctness gates
Run existing FP32/BF16 regression suite before timing. For every shape and budget compare valid DeepGEMM logits bits, candidate score bits, top-k score multisets, unique/in-range indices and sentinel counts. Both full-capacity and eager-known-history selector bounds are checked. Replay must execute without Python chunk planning. Designated cases shrink then restore lengths in the same graph and check refreshed results. Nonaligned total rows exercise tail chunks. Tied index identity is not required, per user agreement. Finite model output alone is not a correctness proof.

## Measurement
One exclusive GB200 node, one GPU at a time for operator measurements. Two reverse-order visits, 30 warm synchronized host-wall samples and 30 cold-L2 CUPTI spans per arm. Record per-kernel traces, live peak, private graph-pool reservation, exact chunk ranges and identities. Full graph captures all chunks into one replay. Eager capacity is same-work dispatch control; eager actual uses its available history bound; graph actual is a diagnostic exact-bound graph and not an arbitrary-length production graph.

The reported budget controls BF16 logits payload, not total graph memory. Candidate FP32 reductions, padding, schedules and output scratch are measured separately. Test startup profiling and capture-pool reservations before publishing a nonzero default. Compare max-rank model latency using fixed KV allocations, then independently check startup reservation/KV headroom.

## Stopping and reporting
Select a Pareto point only after stable repeat measurements, correct scores and representative model-level confirmation. No-op shapes serve as drift controls. Revisit unstable or regressing cases; do not repeat tests with no open question. Report common-load and stress-load tradeoffs separately, unsupported paths explicitly, and unresolved findings without hiding them. Produce English PR material, commands, provenance and a human review package. Eight hours is a permitted research window, not evidence of an optimum.
