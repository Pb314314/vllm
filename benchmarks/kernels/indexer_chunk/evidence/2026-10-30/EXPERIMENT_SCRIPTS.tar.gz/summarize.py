import json,statistics,collections,csv
from pathlib import Path
root=Path('/home/bopang/cg-project/design/indexer-chunk-default-20261030-v2')
rows=[];status={}
for path in sorted((root/'results').glob('*/RESULT.json')):
 d=json.loads(path.read_text());case=d['records'][0]['case'];status[case]=d['status'];groups=collections.defaultdict(list)
 for r in d['records']:groups[(r['budget_MiB'],r['mode'])].append(r)
 for (b,mode),rr in groups.items():
  if len(rr)!=2:continue
  base=groups[(0,mode)]
  if len(base)!=2:continue
  med=lambda key:statistics.median([x for r in rr for x in r[key]])
  basewall=statistics.median([x for r in base for x in r['wall_us']]);basespan=statistics.median([x for r in base for x in r['cold_cupti_span_us']])
  breakdown=next((r['breakdown'] for r in rr if r['breakdown']),None)
  comp=collections.defaultdict(float)
  for name,v in (breakdown or {}).get('kernels',{}).items():
   kind='schedule' if 'metadata' in name or 'schedule' in name else 'deepgemm' if 'paged_mqa_logits' in name else 'candidate_reduce' if 'block_scores' in name else 'topk' if 'topk' in name.lower() else 'other'
   comp[kind]+=v['median']*v['calls_per_invocation']
  row=dict(case=case,budget_MiB=b,mode=mode,chunks=len(rr[0]['chunks']),max_rows=max(z[1]-z[0] for z in rr[0]['chunks']),wall_us=med('wall_us'),wall_change_pct=100*(med('wall_us')/basewall-1),cold_span_us=med('cold_cupti_span_us'),cold_change_pct=100*(med('cold_cupti_span_us')/basespan-1),visit_spread_pct=100*abs(rr[0]['wall_median_us']-rr[1]['wall_median_us'])/med('wall_us'),extra_live_MiB=max(r['extra_live_peak_bytes'] for r in rr)/2**20,graph_pool_MiB=None if rr[0]['graph_reserved_bytes'] is None else max(r['graph_reserved_bytes'] for r in rr)/2**20,breakdown_us=dict(comp))
  rows.append(row)
(root/'SUMMARY.json').write_text(json.dumps(dict(case_status=status,rows=rows),indent=2)+'\n')
lines=['# Chunk budget sweep: interim results','','Only paired forward/reverse visits are shown. Percent changes compare the same mode, same native artifact and same input with chunking disabled. Source identity and correctness receipts remain beside every result.','',f'Completed cases: {sum(x=="complete" for x in status.values())}/{len(json.loads((root/"CASES.json").read_text()))}.','','| Case | Budget MiB | Chunks | Cold GPU span µs | Change | Graph pool MiB | Warm host µs | Visit spread |','|---|---:|---:|---:|---:|---:|---:|---:|']
for r in rows:
 if r['mode']=='graph_capacity':lines.append(f"|{r['case']}|{r['budget_MiB']}|{r['chunks']}|{r['cold_span_us']:.2f}|{r['cold_change_pct']:+.2f}%|{r['graph_pool_MiB']:.1f}|{r['wall_us']:.2f}|{r['visit_spread_pct']:.2f}%|")
(root/'RESULTS.md').write_text('\n'.join(lines)+'\n')
print('Cases',status,'paired comparisons',len(rows))
for r in rows:
 if r['mode']=='graph_capacity' and r['budget_MiB'] in [0,2048,4096,8192]: print(r['case'],r['budget_MiB'],round(r['cold_change_pct'],2),round(r['graph_pool_MiB']))
