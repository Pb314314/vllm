"""Summarize every visit; keep startup transients and bracket drift visible."""
import json
import statistics as st
from pathlib import Path
p=Path(__file__).resolve().parent/'eager_pairs/model_41510'
summary={'job':41510,'scope':'Same prepared batch, restored state before each call; actual-bound eager; rank-maximum synchronized host and GPU event elapsed times. No throughput claim. All visits retained.','cases':{}}
lines=['# Interleaved same-batch eager comparison','','All visits retained, including the initial 512-request baseline transient. Each nonzero visit is compared to the arithmetic mean of its adjacent unchunked visit medians. Bracket disagreement is uncertainty, not a proven effect of chunking. GPU events include CPU launch gaps.','','| Case | Budget MiB | Host medians ms (two visits) | Adjacent-baseline changes | Baseline bracket disagreement |','|---|---:|---|---|---|']
for f in sorted(p.glob('*_pairs_rank0.json')):
 d=json.loads(f.read_text());assert d['status']=='complete',f
 r=d['records'];pairs=[]
 for i,x in enumerate(r):
  if not x['budget_MiB']:continue
  a,b=r[i-1],r[i+1];assert a['budget_MiB']==b['budget_MiB']==0
  pair={'visit':i,'budget_MiB':x['budget_MiB']}
  for metric in ['wall','gpu_event']:
   k=metric+'_median_us';base=(a[k]+b[k])/2
   pair[metric]={'median_us':x[k],'before_us':a[k],'after_us':b[k],'reference_us':base,'change_pct':100*(x[k]/base-1),'baseline_bracket_difference_pct':100*abs(a[k]-b[k])/base}
  pairs.append(pair)
 case=f.name.removesuffix('_pairs_rank0.json')
 value={'pairs':pairs,'unchunked_visits_ms':[x['wall_median_us']/1000 for x in r if not x['budget_MiB']], 'budgets':{}}
 for budget in [1024,1536,2048,4096]:
  ps=[x for x in pairs if x['budget_MiB']==budget]
  value['budgets'][str(budget)]={'visit_changes_pct':[x['wall']['change_pct'] for x in ps],'median_paired_change_pct':st.median(x['wall']['change_pct'] for x in ps),'max_bracket_difference_pct':max(x['wall']['baseline_bracket_difference_pct'] for x in ps)}
  fmt=lambda vals:' / '.join(f'{x:.2f}' for x in vals)
  lines.append(f"|{case}|{budget}|{fmt(x['wall']['median_us']/1000 for x in ps)}|{fmt(x['wall']['change_pct'] for x in ps)}%|{fmt(x['wall']['baseline_bracket_difference_pct'] for x in ps)}%|")
 summary['cases'][case]=value
assert len(summary['cases'])==2
(p/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
(p/'SUMMARY.md').write_text('\n'.join(lines)+'\n')
print('\n'.join(lines))
