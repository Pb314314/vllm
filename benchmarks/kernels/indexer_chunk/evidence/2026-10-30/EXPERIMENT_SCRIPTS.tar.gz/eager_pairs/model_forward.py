import argparse
import gc
import hashlib
import json
import os
import time
import statistics
from pathlib import Path

import torch
from vllm.benchmarks.forward import main as bm
from vllm.benchmarks.forward.capture import ForwardBench, _first_tensor
from vllm.benchmarks.forward.shapes import jitter_kv_lens, parse_case
from vllm.config import set_current_vllm_config
from vllm.utils.argparse_utils import FlexibleArgumentParser
import vllm.envs as envs
import vllm.model_executor.layers.sparse_attn_indexer as idx
import vllm._C_stable_libtorch as native

p = FlexibleArgumentParser()
bm.add_cli_args(p)
p.add_argument('--experiment-dir', required=True)
args = p.parse_args()
out = Path(args.experiment_dir)
out.mkdir(parents=True, exist_ok=True)
assert hashlib.sha256(Path(native.__file__).read_bytes()).hexdigest() == 'f96b1e72533bc79d154f245d0ffc62817fd99fd2987e97b8e4e63a14dbe02f92'
cases = [parse_case(c) for c in args.case]
bm._setup_env()
from vllm import LLM
from vllm.distributed.parallel_state import get_world_group
llm = LLM.from_engine_args(bm._make_engine_args(args, cases))
runner = llm.llm_engine.model_executor.driver_worker.worker.model_runner
world = get_world_group()
cases = [jitter_kv_lens(c, args.kv_len_jitter, runner.model_config.max_model_len, args.seed) for c in cases]
# Benchmark-only: change this setting only between destroyed graphs, with the
# same loaded model and fixed KV allocation. This does not measure startup/KV gain.
envs.disable_envs_cache()
old_plan = idx._decode_chunk_ranges
plans = []
def plan(*a, **kw):
    result = old_plan(*a, **kw)
    plans.append(dict(rows=a[0], width=a[1], budget=a[2], chunks=result))
    return result
idx._decode_chunk_ranges = plan

def capture_eager(self):
    snapshots = [(v, v.clone()) for v in self.state_views]
    def restore():
        for view, saved in snapshots:
            view.copy_(saved)
    records = []
    order = [0,1024,0,1536,0,2048,0,4096,0,4096,0,2048,0,1536,0,1024,0]
    start_event = torch.cuda.Event(enable_timing=True)
    end_event = torch.cuda.Event(enable_timing=True)
    for visit, budget in enumerate(order):
        os.environ['VLLM_SPARSE_INDEXER_MAX_DECODE_LOGITS_MB'] = str(budget)
        assert envs.VLLM_SPARSE_INDEXER_MAX_DECODE_LOGITS_MB == budget
        plans.clear()
        for _ in range(8):
            restore()
            value = self._run_model()
        torch.cuda.synchronize()
        wall, gpu = [], []
        for _ in range(20):
            restore()
            torch.distributed.barrier(group=world.device_group)
            torch.cuda.synchronize()
            t0 = time.perf_counter_ns()
            start_event.record()
            value = self._run_model()
            end_event.record()
            end_event.synchronize()
            wall.append((time.perf_counter_ns()-t0)/1000)
            gpu.append(start_event.elapsed_time(end_event)*1000)
        measurements = torch.tensor([wall,gpu],device=self.device,dtype=torch.float64)
        torch.distributed.all_reduce(measurements,op=torch.distributed.ReduceOp.MAX,group=world.device_group)
        wall,gpu = measurements.cpu().tolist()
        record = dict(visit=visit,budget_MiB=budget,wall_us=wall,gpu_event_us=gpu,wall_median_us=statistics.median(wall),gpu_event_median_us=statistics.median(gpu),plans=list({json.dumps(x,sort_keys=True):x for x in plans}.values()))
        records.append(record)
        (out/f'{self.name}_pairs_rank{world.rank}.json').write_text(json.dumps(dict(status='partial',records=records),indent=2)+'\n')
        if world.rank==0:print('PAIRED',self.name,visit,budget,record['wall_median_us'],record['gpu_event_median_us'],flush=True)
    self.result['eager_pairs'] = records
    self.result['finite'] = bool(torch.isfinite(_first_tensor(value)).all().item())
    assert self.result['finite']
    (out/f'{self.name}_pairs_rank{world.rank}.json').write_text(json.dumps(dict(status='complete',records=records),indent=2)+'\n')
    return value

ForwardBench._capture_and_time = capture_eager
identity=dict(native_sha=hashlib.sha256(Path(native.__file__).read_bytes()).hexdigest(),caller_sha=hashlib.sha256(Path(idx.__file__).read_bytes()).hexdigest(),argv=vars(args),scope='Same prepared batch and restored KV state; eager only, actual host bounds, rank-max wall/GPU events include CPU launch gaps but exclude state restore/barrier; no graph capture between budget arms; real weights and zero historical KV')
(out/f'identity_rank{world.rank}.json').write_text(json.dumps(identity,indent=2,default=str)+'\n')
with torch.inference_mode(),set_current_vllm_config(runner.vllm_config):
    for case in cases:
        os.environ['VLLM_SPARSE_INDEXER_MAX_DECODE_LOGITS_MB']='0'
        result=bm.run_case(runner,case,args)
        assert result['finite']
