"""Run one owned collocated correctness arm, with a bounded lifetime."""

import json
import os
import signal
import socket
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

here = Path(__file__).resolve().parent
variant, folder = sys.argv[1:]
assert variant in ("A", "B")
out = Path(folder)
out.mkdir(parents=True, exist_ok=False)
server = None
status = {"variant": variant, "started": time.time(), "complete": False, "hostname": socket.gethostname(), "allocation": os.environ.get("SLURM_JOB_ID")}
try:
    idle_deadline = time.monotonic() + 120
    while True:
        active = subprocess.check_output(
            ["nvidia-smi", "--query-compute-apps=pid,process_name,used_memory", "--format=csv,noheader"], text=True,
        ).strip()
        if not active:
            break
        (out / "PREEXISTING_GPU_WORK.txt").write_text(active + "\n")
        if time.monotonic() >= idle_deadline:
            raise RuntimeError("Allocated node still has pre-existing GPU work; no benchmark started")
        time.sleep(5)
    with (out / "server.log").open("w") as log:
        server = subprocess.Popen(
            ["bash", str(here / "role.sh"), variant, str(out)],
            stdout=log, stderr=subprocess.STDOUT, start_new_session=True,
        )
        deadline = time.monotonic() + 1200
        while True:
            if server.poll() is not None:
                raise RuntimeError(f"Server exited {server.returncode} before health")
            try:
                with urllib.request.urlopen("http://127.0.0.1:8200/health", timeout=2) as r:
                    if r.status == 200:
                        break
            except Exception:
                pass
            if time.monotonic() > deadline:
                raise TimeoutError("Server readiness exceeded 20 minutes")
            time.sleep(2)
        status["ready"] = time.time()
        with (out / "client.log").open("w") as clientlog:
            result = subprocess.run(
                ["bash", str(here / "run_client.sh"), variant, str(out)],
                stdout=clientlog, stderr=subprocess.STDOUT, timeout=450,
            )
        status["client_exit"] = result.returncode
        assert result.returncode == 0, "Client/protocol failed; see retained results"
        status["complete"] = True
finally:
    if server is not None:
        try:
            os.killpg(server.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
        try:
            server.wait(timeout=20)
        except subprocess.TimeoutExpired:
            os.killpg(server.pid, signal.SIGKILL)
            server.wait(timeout=10)
    status["ended"] = time.time()
    (out / "DRIVER.json").write_text(json.dumps(status, indent=2) + "\n")
    subprocess.run(["nvidia-smi"], stdout=(out / "NVIDIA_END.txt").open("w"))
