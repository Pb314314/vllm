"""Export numeric evidence without private serving logs or runtime clones."""
from pathlib import Path
import json,gzip,hashlib,shutil,tarfile,io
p=Path(__file__).resolve().parent
out=p/'public_evidence'
out.mkdir(exist_ok=True)
for name in ['REPORT.md','REPRODUCE.md','PR_DESCRIPTION.md','HUMAN_REVIEW.md','CODE_REVIEW_GUIDE.md','DEFAULT_TRADEOFF.svg','DEFAULT_TRADEOFF.png','EVIDENCE_AUDIT.json','SOURCE_HASHES.json','PATCH_REPLAY.json','CHECKLIST.md']:
 shutil.copy2(p/'review'/name,out/name)
raw={'schema':1,'note':'Original numeric records, including retained regressions and numerical diagnostics. Full logs, environment identities and model outputs remain in the local experiment archive. Stage implementations differ as documented; do not pool them.','operator':{},'model':{},'eager_pairs':{},'case_identities':{},'proofs':{}}
for stage in ['', 'refinement','tail_policy','tail_policy/balanced','order_ab','order_ab/original','fallback']:
 for f in sorted((p/stage/'results').glob('*/RESULT.json')):
  d=json.loads(f.read_text());assert d['status']=='complete'
  # Records are numeric timings, shapes, kernel names and memory metrics.
  raw['operator'][str(f.relative_to(p))]=d
  ident=json.loads((f.parent/'IDENTITY.json').read_text())
  raw['case_identities'][str(f.parent.relative_to(p))]={k:ident[k] for k in ['case','native_sha','caller_sha','GPU','measurement','benchmark_sha','cases_sha'] if k in ident}
  for proof in sorted(f.parent.glob('proof_*.json')):
   raw['proofs'][str(proof.relative_to(p))]=json.loads(proof.read_text())
for stage,job in [('refinement',41450),('low_budget',41484)]:
 for f in sorted((p/stage/f'model_{job}').glob('RESULT_rank*.json')):
  d=json.loads(f.read_text());assert d['status']=='complete';raw['model'][str(f.relative_to(p))]=d
for f in sorted((p/'eager_pairs/model_41510').glob('*_pairs_rank*.json')):
 d=json.loads(f.read_text());assert d['status']=='complete';raw['eager_pairs'][str(f.relative_to(p))]=d
assert len(raw['eager_pairs'])==8
blob=json.dumps(raw,separators=(',',':'),allow_nan=False).encode()
(out/'RAW_TIMINGS.json.gz').write_bytes(gzip.compress(blob,mtime=0))
summaries={}
for stage in ['e2e','e2e_v41','pd','startup']:
 summaries[stage]=json.loads((p/stage/'FINAL_SUMMARY.json').read_text())
(out/'FUNCTIONAL_SUMMARY.json').write_text(json.dumps(summaries,indent=2)+'\n')
for stage,job in [('refinement',41450),('low_budget',41484),('eager_pairs',41510)]:
 shutil.copy2(p/stage/f'model_{job}'/'SUMMARY.md',out/f'{stage}_MODEL.md')
 shutil.copy2(p/stage/f'model_{job}'/'SUMMARY.json',out/f'{stage}_MODEL.json')
scripts=[]
for stage in ['', 'refinement','tail_policy','order_ab','fallback','e2e','e2e_v41','pd','startup','low_budget','eager_pairs']:
 for f in (p/stage).iterdir():
  if f.is_file() and (f.suffix in ['.py','.sh','.sbatch'] or f.name=='PROTOCOL.md'):
   scripts.append(f)
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w') as tar:
 for f in sorted(set(scripts)):
  data=f.read_bytes();info=tarfile.TarInfo(str(f.relative_to(p)));info.size=len(data);info.mtime=0
  tar.addfile(info,io.BytesIO(data))
(out/'EXPERIMENT_SCRIPTS.tar.gz').write_bytes(gzip.compress(buffer.getvalue(),mtime=0))
manifest={f.name:dict(bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest()) for f in sorted(out.iterdir()) if f.is_file() and f.name!='MANIFEST.json'}
(out/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('files',len(manifest),'compressed raw MiB',(out/'RAW_TIMINGS.json.gz').stat().st_size/2**20)
