#!/usr/bin/env bash
set -euo pipefail
variant=$1
output=$2
here=$(cd "$(dirname "$0")" && pwd)
python=/home/bopang/cg-project/design/indexer-bf16-native-research-20261028/minimal_pr1_20261029/model_runtime_preparation_v1/pd_venv_v1/bin/python
endpoint=http://127.0.0.1:8200
# Root/controller invokes only after the server health check succeeds.
curl --fail --silent --max-time 3 "$endpoint/health" > /dev/null
printf '{"purpose":"64-request actual chunk replay smoke"}\n' > "$output/armed.json"
CAST_E2E_TRACE_DIR='' "$python" "$here/client.py" --standalone \
 --prefill "$endpoint" --decode "$endpoint" --fixture "$here/fixture64.json" \
 --concurrency 64 --max-tokens 2048 --output "$output/client"
CAST_E2E_TRACE_DIR='' "$python" "$here/grade.py" --variant "$variant" --output "$output"
