from pathlib import Path
import json,subprocess
p=Path('/home/bopang/cg-project/design/indexer-chunk-default-20261030-v2')
s=subprocess.check_output(['squeue','-u','bopang','-o','%.12i %.10T %.27j %.10M %.22R'],text=True)
print('\n'.join(l for l in s.splitlines() if 'idx-' in l))
for stage,job in [('startup','41511'),('eager_pairs','41510'),('low_budget','41484')]:
 root=p/stage
 for f in sorted(root.glob(f'results/{job}*/DRIVER.json')):
  d=json.loads(f.read_text());print(stage,f.parent.name,{k:d.get(k) for k in ['complete','ready','ended']})
 for f in sorted(root.glob(f'model_{job}/*rank0.json')):
  if f.name.startswith('identity'):continue
  d=json.loads(f.read_text());r=d.get('records',[]);print(stage,f.name,d.get('status'),'records',len(r),'last',r[-1].get('budget_MiB') if r else None)
 for f in sorted(root.glob(f'results/{job}*/server.log')):
  ls=f.read_text(errors='replace').splitlines();ks=[l for l in ls if any(t in l for t in ['Available KV cache memory','GPU KV cache size','Graph capturing finished','Application startup complete','Traceback','RuntimeError','ValueError'])]
  if ks:print(stage,f.parent.name,'\n'.join(ks[-3:]))
