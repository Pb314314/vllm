import json,statistics,collections
from pathlib import Path
root=Path('/home/bopang/cg-project/design/indexer-chunk-default-20261030-v2')
for stage in [root,root/'refinement',root/'low_budget']:
 for folder in sorted(stage.glob('model_*')):
  if not folder.is_dir() or not (folder/'RESULT_rank0.json').exists():continue
  datasets=[json.loads(p.read_text()) for p in sorted(folder.glob('RESULT_rank*.json'))]
  master=datasets[0];groups=collections.defaultdict(list);rows=[]
  for i,z in enumerate(master['records']):
   peers=[d['records'][i] for d in datasets if i<len(d['records'])]
   assert all((p['case'],p['trial'],p['budget_MiB'])==(z['case'],z['trial'],z['budget_MiB']) for p in peers)
   record=dict(case=z['case'],budget=z['budget_MiB'],trial=z['trial'],us=z['result']['latency_us']['median'],spread_pct=z['result']['latency_us']['sample_spread_pct'],peak_bytes=max(p['result']['peak_allocated_bytes'] for p in peers),graph_bytes=max((p['result'].get('graph_private_reserved_bytes',0) for p in peers)),hidden_bits_equal=all(p['result']['vs_no_chunk_hidden']['bits_equal'] for p in peers),baseline_eager_nondeterministic=any(p['result']['eager_repeat']['max_abs']!=0 for p in peers),max_abs=max(p['result']['vs_no_chunk_hidden']['max_abs'] for p in peers),eager_wall_us=statistics.median(z['result'].get('eager_host_wall_us',[0])))
   groups[z['case']].append(record)
  for case,rs in groups.items():
   b=[r for r in rs if r['budget']==0]
   if len(b)<2:continue
   btime=statistics.median(r['us'] for r in b);bmem=statistics.median(r['peak_bytes'] for r in b);beager=statistics.median(r['eager_wall_us'] for r in b)
   for budget in sorted({r['budget'] for r in rs}):
    subset=[r for r in rs if r['budget']==budget]
    if len(subset)<2:continue
    t=statistics.median(r['us'] for r in subset);mem=statistics.median(r['peak_bytes'] for r in subset);ew=statistics.median(r['eager_wall_us'] for r in subset)
    rows.append(dict(case=case,budget_MiB=budget,graph_ms=t/1000,graph_change_pct=100*(t/btime-1),max_visit_spread_pct=max(r['spread_pct'] for r in subset),peak_GiB=mem/2**30,saved_GiB=(bmem-mem)/2**30,graph_pool_GiB=statistics.median(r['graph_bytes'] for r in subset)/2**30 if any(r['graph_bytes'] for r in subset) else None,eager_wall_ms=ew/1000 if ew else None,eager_change_pct=100*(ew/beager-1) if beager else None,all_hidden_bits_equal=all(r['hidden_bits_equal'] for r in subset),any_baseline_eager_nondeterminism=any(r['baseline_eager_nondeterministic'] for r in b),max_hidden_abs_diff=max(r['max_abs'] for r in subset),visits=subset))
  (folder/'SUMMARY.json').write_text(json.dumps(dict(status=master['status'],rank_count=len(datasets),rows=rows),indent=2)+'\n')
  lines=['# Model forward comparison','','Real weights and routing; synthetic tokens and zero historical KV. Fixed KV allocation across budgets. GPU timings are max-rank one-shot graph forward; not serving throughput. No hidden/token bit-equivalence claim when baseline or no-op paths are nondeterministic. Numerical exceptions are preserved in raw outputs. The refinement adds production-capacity indexer host bounds, actual-bound eager wall time and graph-private reservation.','', '| Case | Budget MiB | Graph ms | Change | Peak saved GiB/GPU | Max sample spread |','|---|---:|---:|---:|---:|---:|']
  for r in rows:lines.append(f"|{r['case']}|{r['budget_MiB']}|{r['graph_ms']:.3f}|{r['graph_change_pct']:+.3f}%|{r['saved_GiB']:.3f}|{r['max_visit_spread_pct']:.2f}%|")
  (folder/'SUMMARY.md').write_text('\n'.join(lines)+'\n')
  print(folder.name,master['status'],'paired summaries',len(rows))
  for r in rows:
   if r['budget_MiB']==2048:print(r['case'],'2GiB delta',round(r['graph_change_pct'],3),'saving',round(r['saved_GiB'],3),'eager',r['eager_change_pct'])
