import json, statistics, collections
from pathlib import Path
root=Path('/home/bopang/cg-project/design/indexer-chunk-default-20261030-v2')
for stage in ['refinement','tail_policy','tail_policy/balanced','order_ab','order_ab/original']:
 p=root/stage; rows=[]; states={}
 for f in sorted((p/'results').glob('*/RESULT.json')):
  d=json.loads(f.read_text()); rr=d.get('records',[])
  if not rr or 'mode' not in rr[0]:continue
  groups=collections.defaultdict(list); states[f.parent.name]=d.get('status')
  for r in rr: groups[r['budget_MiB'],r['mode']].append(r)
  for (b,mode),rs in groups.items():
   bs=groups.get((0,mode),[])
   if len(rs)!=2 or len(bs)!=2:continue
   med=lambda key,seq:statistics.median(v for r in seq for v in r[key])
   t=med('cold_cupti_span_us',rs);bt=med('cold_cupti_span_us',bs)
   w=med('wall_us',rs);bw=med('wall_us',bs)
   row=dict(case=rs[0]['case'],mode=mode,budget_MiB=b,chunks=rs[0]['chunks'],cold_us=t,cold_change_pct=100*(t/bt-1),wall_us=w,wall_change_pct=100*(w/bw-1),extra_live_MiB=max(r['extra_live_peak_bytes'] for r in rs)/2**20,graph_pool_MiB=max((r['graph_reserved_bytes'] or 0) for r in rs)/2**20,visit_spread_pct=100*abs(rs[0]['wall_median_us']-rs[1]['wall_median_us'])/w)
   rows.append(row)
 (p/'SUMMARY.json').write_text(json.dumps(dict(states=states,rows=rows),indent=2)+'\n')
 lines=['# Paired operator comparisons','','Both visits are required; cold CUPTI GPU span and warm synchronized host wall time are distinct measurements. Baseline is the same input, native build and execution mode with chunking disabled.','', '| Case | Budget MiB | Mode | Chunks | Cold µs | Change | Live MiB | Graph pool MiB | Warm host µs |','|---|---:|---|---:|---:|---:|---:|---:|---:|']
 for r in rows:lines.append(f"|{r['case']}|{r['budget_MiB']}|{r['mode']}|{len(r['chunks'])}|{r['cold_us']:.2f}|{r['cold_change_pct']:+.2f}%|{r['extra_live_MiB']:.1f}|{r['graph_pool_MiB']:.1f}|{r['wall_us']:.2f}|")
 (p/'RESULTS.md').write_text('\n'.join(lines)+'\n')
 print(stage,states, 'comparisons',len(rows))
for stage,job in [('e2e','41456'),('e2e_v41','41468')]:
 p=root/stage; arms={}
 for arm in ['0_A','1_B','2_A']:
  f=p/'results'/f'{job}_{arm}'/'RESULT.json'
  if f.exists():arms[arm]=json.loads(f.read_text())
 summary={'job':job,'arms':{a:{k:d.get(k) for k in ['variant','correct','count','protocol_pass','actual_chunk_replay_pass','scope']} for a,d in arms.items()},'comparisons':[]}
 for a,b in [('0_A','1_B'),('0_A','2_A'),('1_B','2_A')]:
  if a not in arms or b not in arms:continue
  da={x['case_id']:x for x in arms[a]['answers']};db={x['case_id']:x for x in arms[b]['answers']}
  assert da.keys()==db.keys()
  summary['comparisons'].append(dict(a=a,b=b,count=len(da),token_string_sequences_equal=sum(da[k]['token_strings']==db[k]['token_strings'] for k in da),parsed_answers_equal=sum(da[k]['parsed']==db[k]['parsed'] for k in da)))
 (p/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n');print(stage,json.dumps(summary))
