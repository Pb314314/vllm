"""Evaluate pre-rendered checkpoint chat fixtures with optional NIXL handoff."""

import argparse
import asyncio
import json
import time
import uuid
from pathlib import Path

import aiohttp


def blocks(value):
    if isinstance(value, int):
        return 1
    if isinstance(value, list):
        return sum(blocks(item) for item in value)
    return 0


async def run(args):
    fixture = json.loads(Path(args.fixture).read_text())
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=False)
    (output / "fixture.json").write_text(json.dumps(fixture, indent=2) + "\n")
    semaphore = asyncio.Semaphore(args.concurrency)
    handoff_barrier = asyncio.Barrier(len(fixture["records"]))
    timeout = aiohttp.ClientTimeout(total=1800)
    async with aiohttp.ClientSession(timeout=timeout, connector=aiohttp.TCPConnector(force_close=True, limit=256)) as session:
        async def metrics(phase):
            for role, endpoint in (("prefill", args.prefill), ("decode", args.decode)):
                async with session.get(endpoint + "/metrics") as response:
                    response.raise_for_status()
                    (output / f"{phase}.{role}.metrics.txt").write_text(await response.text())

        async def post(endpoint, payload, request_id):
            async with session.post(endpoint + "/v1/completions", json=payload, headers={"X-Request-Id": request_id}) as response:
                value = await response.json()
                if response.status != 200:
                    raise RuntimeError((response.status, value))
                return value

        await metrics("before")
        with (output / "requests.jsonl").open("a") as stream:
            async def request(case):
                async with semaphore:
                    record = {"suite": fixture["protocol"], "index": case["index"], "case_id": case["case_id"],
                              "expected_text_diagnostic": case["expected"], "prompt": case["prompt"],
                              "expected_prompt_tokens": case["prompt_tokens"], "concurrency": args.concurrency,
                              "max_tokens": args.max_tokens, "started_unix_ns": time.time_ns(),
                              "http_connection_protocol": "fresh_per_request_force_close_limit256_no_retries", "scope": fixture["scope"], "template_kwargs": fixture["template_kwargs"],
                              "deployment": "standalone_not_PD" if args.standalone else "two_node_PD"}
                    payload = {"model": "deepseek-ai/DeepSeek-V4-Flash-DSpark", "prompt": case["prompt"],
                               "add_special_tokens": False, "max_tokens": args.max_tokens, "temperature": 0.0,
                               "seed": 42, "stream": False, "logprobs": 1}
                    request_id = "indexer-chat-v5-" + uuid.uuid4().hex
                    try:
                        transfer = None
                        if not args.standalone:
                            prefill = dict(payload, max_tokens=1)
                            prefill["kv_transfer_params"] = {"do_remote_decode": True, "do_remote_prefill": False,
                                                           "remote_engine_id": None, "remote_block_ids": None,
                                                           "remote_host": None, "remote_port": None}
                            p_response = await post(args.prefill, prefill, request_id)
                            transfer = p_response.get("kv_transfer_params")
                            if not isinstance(transfer, dict) or not transfer.get("remote_engine_id") or not blocks(transfer.get("remote_block_ids")):
                                raise RuntimeError("No nonempty remote engine/block metadata from P")
                            payload["kv_transfer_params"] = transfer
                            record["prefill_response"] = p_response
                        await handoff_barrier.wait()
                        response = await post(args.decode, payload, request_id)
                        record.update(status="ok", decode_response=response, transfer_metadata=transfer,
                                      remote_block_count=blocks(transfer.get("remote_block_ids")) if transfer else 0)
                        if response["usage"]["prompt_tokens"] != case["prompt_tokens"]:
                            raise RuntimeError(("Rendered/client vs server token count mismatch", case["prompt_tokens"], response["usage"]))
                    except Exception as exc:
                        record.update(status="error", error=repr(exc))
                        raise
                    finally:
                        record["completed_unix_ns"] = time.time_ns()
                        stream.write(json.dumps(record) + "\n")
                        stream.flush()
            results = await asyncio.gather(*(request(case) for case in fixture["records"]), return_exceptions=True)
        await metrics(f"after_c{args.concurrency}")
        errors = [x for x in results if isinstance(x, Exception)]
        if errors:
            raise RuntimeError(f"{len(errors)} requests failed: {errors[0]}")


parser = argparse.ArgumentParser()
parser.add_argument("--fixture", required=True)
parser.add_argument("--prefill", required=True)
parser.add_argument("--decode", required=True)
parser.add_argument("--output", required=True)
parser.add_argument("--concurrency", type=int, default=64)
parser.add_argument("--max-tokens", type=int, default=4096)
parser.add_argument("--standalone", action="store_true")
asyncio.run(run(parser.parse_args()))
