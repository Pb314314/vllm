import argparse,json,re
from decimal import Decimal
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--variant');p.add_argument('--output',type=Path);a=p.parse_args()
rows=[json.loads(x) for x in (a.output/'client/requests.jsonl').read_text().splitlines()]
assert len(rows)==32 and len({x['case_id'] for x in rows})==32
answers=[]
for row in rows:
 c=row.get('decode_response',{}).get('choices',[{}])[0];text=c.get('text','');v=re.findall(r'####\s*\$?\s*(-?[\d,]+(?:\.\d+)?)',text)
 parsed=str(Decimal(v[-1].replace(',','')).normalize()) if v else None
 answers.append(dict(case_id=row['case_id'],status=row['status'],finish_reason=c.get('finish_reason'),correct=parsed==str(Decimal(row['expected_text_diagnostic']).normalize()),parsed=parsed,expected=row['expected_text_diagnostic'],text=text,token_strings=c.get('logprobs',{}).get('tokens'),token_logprobs=c.get('logprobs',{}).get('token_logprobs')))
witnesses=[json.loads(p.read_text()) for p in (a.output/'native_trace').glob('chunk.*.json')]
replay_workers={x['pid'] for x in witnesses if x['event']=='chunk_graph_replay' and any(z['ranges'] for z in x['plans'])}
workers={int(rank):int(pid) for rank,pid in re.findall(r'Worker_TP(\d+)(?:_EP\d+)? pid=(\d+)',(a.output/'server.log').read_text(errors='replace'))}
transport=all(r.get('remote_block_count',0)>0 and r.get('transfer_metadata',{}).get('remote_engine_id') for r in rows)
protocol=transport and all(x['status']=='ok' and x['finish_reason']=='stop' for x in answers)
path_pass=a.variant=='A' or (set(workers)=={0,1,2,3} and set(workers.values())<=replay_workers)
r=dict(variant=a.variant,correct=sum(x['correct'] for x in answers),count=32,protocol_pass=protocol,actual_chunk_replay_pass=path_pass if a.variant=='B' else None,answers=answers,witnesses=witnesses,workers=workers,scope='Two-node NIXL PD functional smoke with prefill barrier; all requests must receive nonempty remote block metadata; 8 MiB budget deliberately forces chunking with 32 requests. Not a default-budget performance benchmark.')
(a.output/'RESULT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k not in ['answers','witnesses']}));raise SystemExit(0 if protocol and path_pass else 1)
