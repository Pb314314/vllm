#!/usr/bin/env bash
# Collocated functional smoke only; root owns allocation/cleanup.
set -euo pipefail
role=$1
variant=$2
output=$3
[[ $role == prefill || $role == decode ]] || exit 2
[[ $variant == A || $variant == B ]] || exit 2
here=$(cd "$(dirname "$0")" && pwd)
base=$(dirname "$here")
runtime="$base/refinement/runtime"
python=/home/bopang/cg-project/design/indexer-bf16-native-research-20261028/minimal_pr1_20261029/model_runtime_preparation_v1/pd_venv_v1/bin/python
mkdir -p "$output"
export PYTHONPATH="$here/hooks:$runtime" PYTHONDONTWRITEBYTECODE=1
export CUDA_VISIBLE_DEVICES=0,1,2,3
export CUDA_HOME=/usr/local/cuda-13.1 CUDA_PATH=/usr/local/cuda-13.1
export PATH="$(dirname "$python"):/home/bopang/vllm/.venv/bin:/home/bopang/cg-project/venv-b4a0fix/bin:/usr/local/cuda-13.1/bin:/usr/bin:/bin"
export DG_JIT_NVCC_COMPILER=/usr/local/cuda-13.1/bin/nvcc
export DJ_JIT_NVCC_COMPILER=/usr/local/cuda-13.1/bin/nvcc
export HF_HOME=/home/bopang/cg-project/design/idx-breakdown-cache/pd-env/hf
export HF_HUB_CACHE="$HF_HOME/hub" HF_HUB_OFFLINE=1
export VLLM_USE_V2_MODEL_RUNNER=1 VLLM_USE_RUST_FRONTEND=0
export VLLM_CACHE_ROOT="$output/cache/vllm"
export DG_JIT_CACHE_DIR="$output/cache/deep_gemm" JIT_CACHE_DIR="$output/cache/deep_gemm"
export TRITON_CACHE_DIR="$output/cache/triton"
export FLASHINFER_WORKSPACE_BASE="$output/cache/flashinfer"
export FLASHINFER_AUTOTUNE_CACHE_DIR="$output/cache/flashinfer_autotune"
export CAST_E2E_TRACE_DIR="$output/native_trace" CAST_E2E_RUNTIME="$runtime"
export CAST_E2E_ARM_FILE="$output/armed.json"
CAST_E2E_NATIVE_SHA=$(sha256sum "$runtime/vllm/_C_stable_libtorch.abi3.so" | cut -d' ' -f1)
export CAST_E2E_NATIVE_SHA
expected=f96b1e72533bc79d154f245d0ffc62817fd99fd2987e97b8e4e63a14dbe02f92
[[ $CAST_E2E_NATIVE_SHA == "$expected" ]] || exit 2
if [[ $variant == A ]]; then export VLLM_SPARSE_INDEXER_MAX_DECODE_LOGITS_MB=0; else export VLLM_SPARSE_INDEXER_MAX_DECODE_LOGITS_MB=8; fi
export VLLM_DEEP_GEMM_WARMUP=skip
if [[ $role == prefill ]]; then port=8100; kv_role=kv_producer; export VLLM_SPARSE_INDEXER_MAX_DECODE_LOGITS_MB=0; else port=8200; kv_role=kv_consumer; fi
export UCX_NET_DEVICES=all UCX_TLS=all UCX_RCACHE_MAX_UNRELEASED=1024
export VLLM_NIXL_SIDE_CHANNEL_HOST=$(hostname -f) VLLM_NIXL_SIDE_CHANNEL_PORT=5660
args=(--host 0.0.0.0 --port "$port" --served-model-name deepseek-ai/DeepSeek-V4-Flash-DSpark
 --tokenizer-mode deepseek_v4 --trust-remote-code
 --revision 62af8fffb2f7030cac4de2f0169f5b8d1101b646
 --tokenizer-revision 62af8fffb2f7030cac4de2f0169f5b8d1101b646
 --max-model-len 1048576 --max-num-seqs 32 --max-num-batched-tokens 4096
 --gpu-memory-utilization 0.85 --tensor-parallel-size 4 --enable-expert-parallel
 --decode-context-parallel-size 1 --kv-cache-dtype fp8 --block-size 256
 --moe-backend deep_gemm_mega_moe --attention-config '{"indexer_kv_dtype":"mxfp4"}'
 --kernel-config '{"sparse_indexer_topk_backend":"auto","enable_jit_warmup":false,"enable_cutedsl_warmup":false,"enable_flashinfer_autotune":false}'
 --compilation-config '{"cudagraph_mode":"FULL_DECODE_ONLY","cudagraph_capture_sizes":[1,2,4,8,16,32]}' --no-numa-bind --seed 0)
args+=(--kv-transfer-config "{\"kv_connector\":\"NixlConnector\",\"kv_role\":\"$kv_role\",\"kv_load_failure_policy\":\"fail\"}")
model="$HF_HUB_CACHE/models--deepseek-ai--DeepSeek-V4-Flash-DSpark/snapshots/62af8fffb2f7030cac4de2f0169f5b8d1101b646"
printf '%s\0' "$python" -m vllm.entrypoints.cli.main serve "$model" "${args[@]}" > "$output/command.argv0"
echo $$ > "$output/server_pid.txt"
cd /tmp
exec "$python" -m vllm.entrypoints.cli.main serve "$model" "${args[@]}"
