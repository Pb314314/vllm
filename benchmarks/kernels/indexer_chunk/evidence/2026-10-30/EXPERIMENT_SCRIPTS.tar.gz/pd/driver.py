"""Owned two-node A/B/A NIXL functional comparison."""
import json,os,signal,subprocess,sys,time,urllib.request
from pathlib import Path
p=Path(__file__).resolve().parent
nodes=subprocess.check_output(['scontrol','show','hostnames',os.environ['SLURM_JOB_NODELIST']],text=True).splitlines()
assert len(nodes)==2
nodes=dict(zip(['prefill','decode'],nodes));job=os.environ['SLURM_JOB_ID']
urls={k:f'http://{v}:{8100 if k=="prefill" else 8200}' for k,v in nodes.items()}
py=sys.executable
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
def remote(role,*cmd):return ['srun','--jobid='+job,'--overlap','-N1','-n1','--cpus-per-task=16','-w',nodes[role],*cmd]
for trial,variant in enumerate(['A','B','A']):
 arm=p/'results'/f'{job}_{trial}_{variant}';arm.mkdir(parents=True,exist_ok=False)
 procs={};logs=[];status={'variant':variant,'nodes':nodes,'complete':False,'started':time.time()}
 try:
  for role in nodes:
   d=arm/role;d.mkdir()
   for attempt in range(25):
    check=subprocess.run(remote(role,'nvidia-smi','--query-compute-apps=pid,process_name,used_memory','--format=csv,noheader'),capture_output=True,text=True,timeout=30)
    assert check.returncode==0,check.stderr
    if not check.stdout.strip():break
    (d/'PREEXISTING_GPU_WORK.txt').write_text(check.stdout)
    time.sleep(5)
   else:raise RuntimeError('Existing GPU work on '+role+'; refusing overlap')
   log=(d/'server.log').open('w');logs.append(log)
   procs[role]=subprocess.Popen(remote(role,'bash',str(p/'role.sh'),role,variant,str(d)),stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  deadline=time.monotonic()+2100;ready=set()
  while len(ready)<2:
   for role,proc in procs.items():
    if proc.poll() is not None:raise RuntimeError(f'{role} exited before readiness: {proc.returncode}')
    if role in ready:continue
    try:
     with opener.open(urls[role]+'/health',timeout=2) as response:
      if response.status==200:ready.add(role)
    except Exception:pass
   if time.monotonic()>deadline:raise TimeoutError('PD readiness exceeded 35 minutes')
   time.sleep(2)
  status['ready']=time.time();(arm/'decode/armed.json').write_text('{"purpose":"PD chunk replay witness"}\n')
  env=os.environ.copy();env['NO_PROXY']=env['no_proxy']='*'
  with (arm/'client.log').open('w') as log:
   result=subprocess.run([py,str(p/'client.py'),'--prefill',urls['prefill'],'--decode',urls['decode'],'--fixture',str(p/'fixture32.json'),'--output',str(arm/'decode/client'),'--concurrency','32','--max-tokens','2048'],stdout=log,stderr=subprocess.STDOUT,env=env,timeout=600)
  status['client_exit']=result.returncode;assert result.returncode==0,'PD client failed'
  grade=subprocess.run([py,str(p/'grade.py'),'--variant',variant,'--output',str(arm/'decode')],capture_output=True,text=True,timeout=60)
  (arm/'grade.log').write_text(grade.stdout+grade.stderr);status['grade_exit']=grade.returncode
  assert grade.returncode==0,'PD protocol or chunk witness failed'
  status['complete']=True
 finally:
  for proc in procs.values():
   if proc.poll() is None:os.killpg(proc.pid,signal.SIGTERM)
  for proc in procs.values():
   try:proc.wait(timeout=40)
   except subprocess.TimeoutExpired:
    os.killpg(proc.pid,signal.SIGKILL);proc.wait(timeout=10)
  for log in logs:log.close()
  status['ended']=time.time();(arm/'DRIVER.json').write_text(json.dumps(status,indent=2)+'\n')
