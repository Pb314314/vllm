from pathlib import Path
import json,hashlib,difflib,subprocess,shutil
root=Path('/home/bopang/cg-project/design/indexer-chunk-default-20261030-v2');out=root/'review';out.mkdir(exist_ok=True)
wt=Path('/home/bopang/cg-project/wt-indexer-chunk-bf16');baseline=Path('/home/bopang/cg-project/design/indexer-chunk-combined-20261030-v1/baseline');compat=Path('/home/bopang/cg-project/wt-indexer-compat-62172-64138')
manifest=json.loads((baseline.parent/'BASELINE.json').read_text());parts=[];stats=[];hashes={}
paths=['vllm/envs.py','vllm/model_executor/layers/sparse_attn_indexer.py','tests/kernels/test_top_k_per_row.py','docs/configuration/conserving_memory.md']
paths += [str(p.relative_to(wt)) for p in sorted((wt/'benchmarks/kernels/indexer_chunk').glob('*')) if p.is_file()]
for name in paths:
 b=baseline/name
 if b.exists():old=b.read_text()
 elif name=='tests/kernels/test_top_k_per_row.py':
  b=compat/name;assert hashlib.sha256(b.read_bytes()).hexdigest()==manifest['integration_manifest'][name];old=b.read_text()
 elif name.startswith('benchmarks/'):old=''
 else:old=subprocess.check_output(['git','-C',str(wt),'show','HEAD:'+name],text=True)
 new=(wt/name).read_text();diff=list(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+name if old else '/dev/null',tofile='b/'+name))
 if not diff:continue
 parts.append('diff --git a/'+name+' b/'+name+'\n'+('new file mode 100644\n' if not old else '')+''.join(diff));stats.append({'path':name,'added':sum(s.startswith('+') and not s.startswith('+++') for s in diff),'deleted':sum(s.startswith('-') and not s.startswith('---') for s in diff)})
 hashes[name]=dict(before_sha256=hashlib.sha256(old.encode()).hexdigest() if old else None,after_sha256=hashlib.sha256(new.encode()).hexdigest())
 for which,text in [('before',old),('after',new)]:
  dest=out/which/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(text)
(out/'PR2_ONLY.patch').write_text(''.join(parts));(out/'DIFF_STATS.json').write_text(json.dumps(stats,indent=2)+'\n');(out/'SOURCE_HASHES.json').write_text(json.dumps(hashes,indent=2)+'\n')
shutil.copy2(root/'ADDRESS_DEPENDENCY.patch',out/'ADDRESS_DEPENDENCY.patch')
for f in ['/tmp/finalize_chunk_summaries.py','/tmp/summarize_chunk_models_v2.py']:
 shutil.copy2(f,root/Path(f).name)
for kind in ['vllm/','tests/','benchmarks/','docs/']:
 print(kind,sum(s['added'] for s in stats if s['path'].startswith(kind)),sum(s['deleted'] for s in stats if s['path'].startswith(kind)))
print('PATCH',out/'PR2_ONLY.patch')
