import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
p=Path('/home/bopang/cg-project/design/indexer-chunk-default-20261030-v2');out=p/'review'
f=json.loads((p/'refinement/SUMMARY.json').read_text())['rows'];m=json.loads((p/'refinement/model_41450/SUMMARY.json').read_text())['rows']
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
fig,axs=plt.subplots(1,3,figsize=(16,4.8),layout='constrained')
for case,label,color in [('c1_r4096_q8_l8192_k512','4,096 Q rows','#2b6cb0'),('c1_r8192_q8_l8192_k512','8,192 Q rows','#b45309')]:
 rs=sorted([r for r in f if r['case']==case and r['mode']=='graph_capacity' and r['budget_MiB']],key=lambda r:r['budget_MiB'])
 axs[0].plot([r['budget_MiB']/1024 for r in rs],[r['cold_change_pct'] for r in rs],'-o',label=label,color=color)
 axs[1].plot([r['budget_MiB']/1024 for r in rs],[r['graph_pool_MiB']/1024 for r in rs],'-o',label=label,color=color)
for ax in axs[:2]:
 ax.axvline(2,color='#15803d',linestyle='--',alpha=.7);ax.set_xlabel('BF16 payload budget (GiB)');ax.set_xticks([1.5,2,2.5,3,4]);ax.grid(alpha=.15)
axs[0].set_title('Indexer GPU cost vs no chunk');axs[0].set_ylabel('Cold CUPTI span change (%)');axs[0].legend();axs[1].set_title('Indexer private graph pool');axs[1].set_ylabel('Reserved memory (GiB)')
rs=[r for r in m if r['budget_MiB']==2048]
labels=['256 × 8\n8K','512 × 8\n8K','1,024 × 8\n4K','320 × 8\nmixed']
x=list(range(len(rs)))
axs[2].bar(x,[r['saved_GiB'] for r in rs],color='#15803d',alpha=.8)
for i,r in enumerate(rs):axs[2].text(i,r['saved_GiB']+.3,f"+{r['graph_change_pct']:.2f}% time",ha='center',fontsize=9)
axs[2].set_xticks(x,labels);axs[2].set_xlabel('Requests × query rows / effective history');axs[2].set_ylabel('Peak allocated memory saved (GiB/GPU)');axs[2].set_ylim(0,20);axs[2].set_title('V4.1 TP4 model forward, 2 GiB budget')
fig.suptitle('2 GiB is a memory–latency tradeoff, not a universal fastest setting',fontsize=14)
fig.supxlabel('Left/middle: synthetic MXFP4, C1 source, W=1M, L=8K. Right: real weights, synthetic tokens + zero KV; not serving throughput.',fontsize=9)
for ext in ['svg','png']:fig.savefig(out/f'DEFAULT_TRADEOFF.{ext}',dpi=160)
print(out/'DEFAULT_TRADEOFF.png')
