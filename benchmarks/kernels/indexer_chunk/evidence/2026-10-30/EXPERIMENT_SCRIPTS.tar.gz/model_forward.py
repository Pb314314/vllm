import argparse
import gc
import hashlib
import json
import os
from pathlib import Path

import torch
from vllm.benchmarks.forward import main as bm
from vllm.benchmarks.forward.capture import ForwardBench, _first_tensor
from vllm.benchmarks.forward.shapes import jitter_kv_lens, parse_case
from vllm.config import set_current_vllm_config
from vllm.utils.argparse_utils import FlexibleArgumentParser
import vllm.envs as envs
import vllm.model_executor.layers.sparse_attn_indexer as idx
import vllm._C_stable_libtorch as native

p = FlexibleArgumentParser()
bm.add_cli_args(p)
p.add_argument('--experiment-dir', required=True)
args = p.parse_args()
out = Path(args.experiment_dir)
out.mkdir(parents=True, exist_ok=True)
assert hashlib.sha256(Path(native.__file__).read_bytes()).hexdigest() == 'f96b1e72533bc79d154f245d0ffc62817fd99fd2987e97b8e4e63a14dbe02f92'
cases = [parse_case(c) for c in args.case]
bm._setup_env()
from vllm import LLM
from vllm.distributed.parallel_state import get_world_group
llm = LLM.from_engine_args(bm._make_engine_args(args, cases))
runner = llm.llm_engine.model_executor.driver_worker.worker.model_runner
world = get_world_group()
cases = [jitter_kv_lens(c, args.kv_len_jitter, runner.model_config.max_model_len, args.seed) for c in cases]
# Benchmark-only: change this setting only between destroyed graphs, with the
# same loaded model and fixed KV allocation. This does not measure startup/KV gain.
envs.disable_envs_cache()
old_plan = idx._decode_chunk_ranges
plans = []
def plan(*a, **kw):
    result = old_plan(*a, **kw)
    plans.append(dict(rows=a[0], width=a[1], budget=a[2], chunks=result))
    return result
idx._decode_chunk_ranges = plan
old_capture = ForwardBench._capture_and_time
hidden = None
def capture(self):
    global hidden
    value = old_capture(self)
    hidden = _first_tensor(value).detach().cpu().clone()
    self.result['cuda_allocated_after_bytes'] = torch.cuda.memory_allocated()
    self.result['cuda_reserved_after_bytes'] = torch.cuda.memory_reserved()
    return value
ForwardBench._capture_and_time = capture
identity = dict(native_sha=hashlib.sha256(Path(native.__file__).read_bytes()).hexdigest(), caller_sha=hashlib.sha256(Path(idx.__file__).read_bytes()).hexdigest(), argv=vars(args), rank=world.rank, device=str(torch.cuda.get_device_properties(0)), scope='real weights, real routing, synthetic tokens, zero historical KV; target forward only; one-shot full graph, max rank graph-event latency; fixed KV allocation across budgets')
(out/f'identity_rank{world.rank}.json').write_text(json.dumps(identity, indent=2, default=str))
records = []
with torch.inference_mode(), set_current_vllm_config(runner.vllm_config):
    for case in cases:
        reference = None
        for trial, budget in enumerate([0, 1024, 2048, 4096, 8192, 8192, 4096, 2048, 1024, 0]):
            os.environ['VLLM_SPARSE_INDEXER_MAX_DECODE_LOGITS_MB'] = str(budget)
            assert envs.VLLM_SPARSE_INDEXER_MAX_DECODE_LOGITS_MB == budget
            plans.clear()
            gc.collect()
            torch.cuda.empty_cache()
            torch.cuda.reset_peak_memory_stats()
            result = bm.run_case(runner, case, args)
            assert result['finite'], (case.name, budget, 'nonfinite')
            if reference is None:
                reference = hidden.clone()
            delta = (hidden.float()-reference.float())
            result['vs_no_chunk_hidden'] = dict(bits_equal=torch.equal(hidden.view(torch.int16), reference.view(torch.int16)), max_abs=delta.abs().max().item(), relative_rms=(delta.square().mean().sqrt()/reference.float().square().mean().sqrt().clamp_min(1e-12)).item())
            torch.save(hidden, out / f'{case.name}_trial{trial}_budget{budget}_rank{world.rank}.pt')
            unique = {json.dumps(x, sort_keys=True):x for x in plans}
            result['observed_plans'] = list(unique.values())
            result['peak_allocated_bytes'] = torch.cuda.max_memory_allocated()
            record = dict(case=case.name, requests=[vars(r) for r in case.requests], budget_MiB=budget, trial=trial, result=result)
            records.append(record)
            (out/f'RESULT_rank{world.rank}.json').write_text(json.dumps(dict(status='partial', records=records), indent=2))
            if world.rank == 0:
                print('MEASURED', case.name, budget, result['latency_us']['median'], result['vs_no_chunk_hidden'], result['observed_plans'], flush=True)
(out/f'RESULT_rank{world.rank}.json').write_text(json.dumps(dict(status='complete', records=records), indent=2))
