from pathlib import Path
import json,re
p=Path(__file__).resolve().parent/'startup'
summary={'scope':'Same V4.1-Flash TP4+EP, DSpark7, max model1M, max sequences1024, tokens8192, FULL_DECODE_ONLY, gpu_memory_utilization0.85; owned isolated nodes; startup only, no throughput or accuracy claim.','arms':{}}
for job,arm in [(41502,'A'),(41511,'B')]:
 folder=p/'results'/f'{job}_0_{arm}';d=json.loads((folder/'DRIVER.json').read_text());text=(folder/'server.log').read_text()
 caps=[float(x) for x in re.findall(r'Graph capturing finished in \d+ secs, took ([\d.]+) GiB',text)]
 kv=[float(x) for x in re.findall(r'Available KV cache memory: ([-\d.]+) GiB',text)]
 assert len(caps)>=4 and len(set(caps[:4]))==1 and kv
 if arm=='A':assert not d['complete'] and kv[0]<0 and 'No available memory for the cache blocks' in text
 else:
  assert d['complete'] and d.get('ready') and 'Application startup complete' in text
  assert (folder/'READY.metrics.txt').stat().st_size>0
  assert len(caps)==8 and len(set(caps[4:]))==1
 summary['arms'][arm]={'job':job,'budget_MiB':0 if arm=='A' else 2048,'health_pass':d['complete'],'profiling_capture_GiB_per_worker':caps[0],'available_KV_GiB_per_worker':kv[0],'final_capture_GiB_per_worker':caps[-1] if arm=='B' else None,'failure':None if arm=='B' else 'Negative KV headroom; no cache blocks'}
summary['interpretation']='KV headroom includes both chunked graph/scratch reduction and replacing the old conservative full FP32-copy profiling reservation on eligible BF16 paths. Do not interpret the entire KV delta as actual tensor bytes saved. The existing post-capture manual KV hint adds actual graph bytes to peak_activation_memory which already includes a graph estimate; it is not an independent measurement of under-reservation.'
(p/'FINAL_SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
