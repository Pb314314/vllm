# Prioritized normal-workload serving confirmation

User priority: establish acceptable common-workload performance before spending more time on extreme concurrency. Representative shapes are provisional pending production workload details; do not claim they represent all deployments.

Two exclusive single-node jobs: TP4+EP and DP4/TP1/EP4. Real V4.1 Flash, DSpark7 adaptive enabled, FULL decode graphs, same immutable PR2 build. Both arms use equal fixed 16 GiB KV per GPU; startup profile is bounded at 2 GiB in both, restored before actual graph capture. No capacity-benefit claim.

Global concurrency / input / output: 128 / 4096 / 256; 512 / 4096 / 256; 256 / 16384 / 256. Each shape gets a separate 64-output warmup at matching concurrency followed by two identical-seed measured runs of two request waves. A(no chunk), B(2 GiB), A(no chunk), all on the same node and common compilation cache. Synthetic random prompts, greedy temperature 0, ignore EOS, prefix caching off. Not task accuracy.

No adaptive-manager, graph-replay or producer hooks execute during steady state. Only the fixed-KV startup profile override remains. Client endpoint probe disabled after explicit health and smoke checks, avoiding an unobserved long probe before each phase. Do not directly compare this protocol's absolute latency to the older instrumented run as a code effect.

Report per-run output throughput, mean/p99 TPOT/TTFT, errors and preemptions; retain both unchunked baselines and repeated-run variation. Low-concurrency DEP may not trigger chunking: a flat result then supports unchanged-path performance only. The timed run has no per-step path observer, so it cannot independently prove chunk activation for each workload. Prior graph traces and fixed-shape activation receipts are separate evidence. No weighted production average without production traffic weights.

High-concurrency regressions remain in the report; these normal-workload tests do not erase them. Production code and 2 GiB default are unchanged pending evidence.
