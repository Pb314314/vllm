import argparse
import collections
import gzip
import hashlib
import json
import statistics
import tarfile
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('--root', type=Path, required=True)
p.add_argument('--out', type=Path, required=True)
a = p.parse_args()
root, out = a.root, a.out
out.mkdir(parents=True, exist_ok=True)
manifest = []
raw = {}

def read(path):
    data = path.read_bytes()
    manifest.append(dict(path=str(path.relative_to(root)), bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
    return json.loads(data)

def write(name, data):
    (out / name).write_text(json.dumps(data, indent=2) + '\n')

def compressed(name, data):
    with gzip.open(out / name, 'wt') as f:
        json.dump(data, f, separators=(',', ':'))

model_rows = []
correctness = []
for stage, job in [('model', '41570'), ('dep_model', '41604'), ('dep_imbalance', '41618')]:
    folder = root / stage / f'model_{job}'
    paths = sorted(folder.glob('RESULT_rank*.json'))
    assert len(paths) == 4
    ds = [read(f) for f in paths]
    assert all(d['status'] == 'complete' for d in ds)
    assert len({len(d['records']) for d in ds}) == 1
    identities = [read(f) for f in sorted(folder.glob('identity_rank*.json'))]
    raw[stage] = dict(results=ds, identities=identities)
    groups = collections.defaultdict(list)
    for i, r in enumerate(ds[0]['records']):
        peers = [d['records'][i] for d in ds]
        assert all((x['case'], x['trial'], x['budget_MiB']) == (r['case'], r['trial'], r['budget_MiB']) for x in peers)
        assert all(x['result']['finite'] for x in peers)
        assert all(x['result']['latency_us']['timer'] == 'graph_events_rank_max' for x in peers)
        groups[r['case']].append(dict(
            budget=r['budget_MiB'], trial=r['trial'],
            graph_ms=r['result']['latency_us']['median'] / 1000,
            spread_pct=max(x['result']['latency_us']['sample_spread_pct'] for x in peers),
            peak_GiB=max(x['result']['peak_allocated_bytes'] for x in peers) / 2**30,
            graph_pool_GiB=max(x['result']['graph_private_reserved_bytes'] for x in peers) / 2**30,
            eager_ms=statistics.median(r['result']['eager_host_wall_us']) / 1000,
            all_hidden_bits_equal=all(x['result']['vs_no_chunk_hidden']['bits_equal'] for x in peers),
            max_hidden_abs_diff=max(x['result']['vs_no_chunk_hidden']['max_abs'] for x in peers),
            all_replay_deterministic=all(x['result']['graph_deterministic'] for x in peers),
            requests_per_rank=[len(x['requests']) for x in peers],
            q_rows_per_rank=[x['result']['num_tokens_after_padding'] for x in peers],
            k_lengths_per_rank=[sorted({z['kv_len'] for z in x['requests']}) for x in peers],
        ))
    for case, visits in groups.items():
        base = [v for v in visits if v['budget'] == 0]
        assert len(base) == 2
        base_ms = statistics.mean(v['graph_ms'] for v in base)
        base_mem = statistics.mean(v['peak_GiB'] for v in base)
        drift = 100 * (max(v['graph_ms'] for v in base) / min(v['graph_ms'] for v in base) - 1)
        eager_drift = 100 * (max(v['eager_ms'] for v in base) / min(v['eager_ms'] for v in base) - 1)
        for budget in [0, 2048, 4096]:
            vs = [v for v in visits if v['budget'] == budget]
            assert len(vs) == 2
            ms = statistics.mean(v['graph_ms'] for v in vs)
            row = dict(stage=stage, job=job, case=case, budget_MiB=budget,
                       baseline_ms=base_ms, graph_ms=ms, graph_change_pct=100*(ms/base_ms-1),
                       baseline_drift_pct=drift, max_sample_spread_pct=max(v['spread_pct'] for v in vs),
                       peak_saved_GiB_per_GPU=base_mem-statistics.mean(v['peak_GiB'] for v in vs),
                       graph_pool_GiB=statistics.mean(v['graph_pool_GiB'] for v in vs),
                       baseline_eager_drift_pct=eager_drift, visits=vs)
            model_rows.append(row)
            correctness.append(dict(stage=stage, case=case, budget_MiB=budget,
                hidden_bits_match_first_baseline=all(v['all_hidden_bits_equal'] for v in vs),
                max_hidden_abs_diff=max(v['max_hidden_abs_diff'] for v in vs),
                same_graph_repeat_bitwise=all(v['all_replay_deterministic'] for v in vs)))

serving = []
serving_raw = {}
text_hashes = {}
for stage, job in [('serve', '41572'), ('dep_serve', '41600')]:
    for folder in sorted((root / stage / 'results').glob(job + '_*')):
        driver = read(folder / 'DRIVER.json')
        assert driver['complete']
        serving_raw[str(folder.relative_to(root)) + '/DRIVER'] = driver
        for path in sorted(folder.glob('c*_i*.json')):
            if path.name.endswith('.command.json'):
                continue
            d = read(path)
            assert d['failed'] == 0 and not any(d['errors'])
            key = str(path.relative_to(root))
            # Full text and per-token ITL arrays remain local. Preserve all
            # aggregate and per-request numeric receipts plus string hashes.
            compact = {k:v for k,v in d.items() if k not in ('generated_texts', 'itls')}
            compact['generated_text_sha256'] = [hashlib.sha256(t.encode()).hexdigest() for t in d['generated_texts']]
            serving_raw[key] = compact
            text_hashes[(stage, folder.name, path.stem)] = compact['generated_text_sha256']
            serving.append(dict(stage=stage, arm=folder.name, workload=path.stem,
                completed=d['completed'], input_tokens=min(d['input_lens']), output_tokens=min(d['output_lens']),
                duration_s=d['duration'], output_tokens_s=d['output_throughput'],
                mean_tpot_ms=d['mean_tpot_ms'], p99_tpot_ms=d['p99_tpot_ms'],
                mean_ttft_ms=d['mean_ttft_ms'], p99_ttft_ms=d['p99_ttft_ms'],
                acceptance_length=d['spec_decode_acceptance_length'], failed=d['failed']))
serving_comparisons = []
for stage in ['serve', 'dep_serve']:
    for name in sorted({r['workload'] for r in serving if r['stage'] == stage}):
        rs = sorted([r for r in serving if r['stage']==stage and r['workload']==name], key=lambda r:r['arm'])
        assert len(rs)==3
        aa, bb, az = rs
        a0, b, a1 = [r['output_tokens_s'] for r in rs]
        hs = [text_hashes[(stage, r['arm'], name)] for r in rs]
        assert len(hs[0]) == len(hs[1]) == len(hs[2])
        serving_comparisons.append(dict(stage=stage, workload=name, arms=rs,
            throughput_change_vs_A1_pct=100*(b/a0-1), throughput_change_vs_A2_pct=100*(b/a1-1),
            baseline_drift_pct=100*(max(a0,a1)/min(a0,a1)-1),
            generated_string_match_A1_A2=sum(x==y for x,y in zip(hs[0],hs[2]))/len(hs[0]),
            generated_string_match_A1_B=sum(x==y for x,y in zip(hs[0],hs[1]))/len(hs[0])))

write('MODEL_SUMMARY.json', model_rows)
write('CORRECTNESS_SUMMARY.json', correctness)
write('SERVING_COMPARISON.json', serving_comparisons)
compressed('MODEL_RAW.json.gz', raw)
compressed('SERVING_RECEIPTS.json.gz', serving_raw)
write('SOURCE_MANIFEST.json', manifest)

lines = ['# PR2 completed measurements: fixed-shape, DEP and adaptive serving', '',
    '**Status:** data consolidation only. No new experiments are running. The short-output follow-ups (41655/41656) were canceled during startup at the user’s request and supply no performance results. Production head remains `d51f40aeffe014e4ee1f77759b22501893f84d5e`; no default change is made here.', '',
    '## What the evidence establishes', '',
    '- Query-row chunking substantially reduces measured peak allocated memory in the tested large shapes. Fixed-shape FULL graph model-forward deltas are small relative to the whole forward; they are not serving-throughput estimates.',
    '- Actual adaptive serving has unresolved unfavorable results, including 2 GiB throughput below both unchunked baselines at high concurrency. Baseline drift is shown rather than averaged away.',
    '- Normal-concurrency workloads with several thousand output tokens are NOT covered. The current 2 GiB default is provisional, not an established production optimum.',
    '- Score/top-k correctness from the earlier evidence remains separate from model hidden states and generated tokens. Repeated baseline and same-graph hidden-state differences occur; this package does not establish universal model-output bit equivalence.', '',
    '## Workload and timing definitions', '',
    'All measurements use actual DeepSeek-V4.1-Flash weights on four GB200 GPUs, max model length 1,048,576, MXFP4 indexer cache and the same BF16 top-k prerequisites/native offset fix in every arm. TP4 uses EP; DEP is DP4 + TP1 + EP4. This package does not compare against today’s latest main without prerequisites.', '',
    'Fixed-shape runs use synthetic tokens and zero historical KV, real expert routing, target model only (no drafter, sampling, adaptive policy or HTTP). KV allocation is fixed at 32 GiB/GPU. Budget visits are 0/2/4/4/2/0 GiB, 150 graph samples/visit. Each sample is the maximum of four rank times; tables average the two visit medians. The timed span excludes state restoration and the pre-forward barrier, but includes model communication. Graph capture uses production-capacity indexer bounds and otherwise exact-shape metadata; it bypasses production graph-bucket dispatch. It is not a traffic-weighted average.', '',
    'Peak saved means the difference in peak allocated bytes, taking the maximum across GPUs in each visit. It includes scratch effects and is not the BF16 payload alone. Graph-private reserved memory is reported separately in JSON. Neither is the entire serving graph-pool savings or extra allocatable KV capacity.', '',
    '## Fixed-shape model forward', '',
    'Q is query rows per request; K is effective history including the query. TP request counts are global; DEP counts in case names are per DP rank. For `qmix`, each of 1/2/4/8 query lengths has 512 requests (7,680 total rows).', '',
    '| Topology / case | Budget MiB | Baseline → chunk ms | Change | Peak saved GiB/GPU | A/A drift | Max visit sample spread |',
    '|---|---:|---:|---:|---:|---:|---:|']
for r in model_rows:
    if r['budget_MiB'] and r['stage'] != 'dep_imbalance':
        lines.append(f"|{r['stage']} / {r['case']}|{r['budget_MiB']}|{r['baseline_ms']:.3f} → {r['graph_ms']:.3f}|{r['graph_change_pct']:+.3f}%|{r['peak_saved_GiB_per_GPU']:.3f}|{r['baseline_drift_pct']:.3f}%|{r['max_sample_spread_pct']:.3f}%|")
lines += ['', 'Do not interpret sub-noise negative deltas as speedups. In particular, DEP 256-request/rank, 4 GiB has a 59.19% within-visit sample-median spread; its small aggregate delta is not a precise effect estimate. All samples are retained.', '',
    '## DEP unequal history', '',
    'Each DP rank has 512 requests × 8 query rows. History lengths by rank are balanced `[4K,4K,4K,4K]`, skew `[2K,2K,4K,8K]`, and rotated `[8K,4K,2K,2K]`. Global request count and total effective history positions are identical. Each layout is compared against its own baseline. This tests unequal K work with equal Q, NOT unequal request counts or production DP graph padding.', '',
    '| Layout | Budget MiB | Baseline → chunk ms | Change | A/A drift | Max visit sample spread |',
    '|---|---:|---:|---:|---:|---:|']
for r in model_rows:
    if r['budget_MiB'] and r['stage']=='dep_imbalance':
        lines.append(f"|{r['case']}|{r['budget_MiB']}|{r['baseline_ms']:.3f} → {r['graph_ms']:.3f}|{r['graph_change_pct']:+.3f}%|{r['baseline_drift_pct']:.3f}%|{r['max_sample_spread_pct']:.3f}%|")
lines += ['', 'The skew 2 GiB arm has a 33.44% within-visit spread. Its median remains recorded, but it cannot support a precise sub-percent guarantee. The rotated case is less noisy. No per-collective profiler was run, so this does not isolate EP waiting time.', '',
    '## Actual adaptive serving: all three arms', '',
    'A1/B/A2 run on the same node per topology: A = chunk disabled; B = 2 GiB. DSpark7 adaptive verification is enabled; synthetic random prompts, temperature 0, ignore EOS, prefix caching off. Fixed 16 GiB KV/GPU. Both arms temporarily bound only startup profiling at 2 GiB before restoring the real budget for capture/serving. This excludes extra-KV-capacity benefits. There are two request waves per measured workload after a separate short warmup.', '',
    'TP4: max sequences 2048, max batched tokens 16384, captures through 16384. DEP: max sequences 1024/rank, max batched tokens 8192/rank, captures through 8192. Client concurrency is global offered concurrency, not proof of achieved simultaneous decode batch. Adaptive profiling is performed separately on each boot.', '',
    '| Topology / offered concurrency | Input / output tokens | A1 tok/s | 2 GiB tok/s | A2 tok/s | B vs A1 / A2 | A/A drift |',
    '|---|---:|---:|---:|---:|---:|---:|']
for r in serving_comparisons:
    x,b,z = r['arms']
    lines.append(f"|{r['stage']} / {r['workload'].split('_')[0][1:]}|{x['input_tokens']} / {x['output_tokens']}|{x['output_tokens_s']:.1f}|{b['output_tokens_s']:.1f}|{z['output_tokens_s']:.1f}|{r['throughput_change_vs_A1_pct']:+.2f}% / {r['throughput_change_vs_A2_pct']:+.2f}%|{r['baseline_drift_pct']:.2f}%|")
lines += ['', 'A1/A2 variation invalidates a universal speedup claim. Throughput below both baselines at TP4 c2048/128-in/1024-out and DEP c2048/c4096 is an unresolved unfavorable signal, not explained away by fixed-shape results. A causal kernel attribution and stable magnitude are still missing.', '',
    '| Topology / workload | Mean TPOT A1 / B / A2 ms | P99 TPOT A1 / B / A2 ms |',
    '|---|---:|---:|']
for r in serving_comparisons:
    lines.append('|'+r['stage']+' / '+r['workload']+'|'+' / '.join(f"{x['mean_tpot_ms']:.2f}" for x in r['arms'])+'|'+' / '.join(f"{x['p99_tpot_ms']:.2f}" for x in r['arms'])+'|')
lines += ['', 'These are request TPOT statistics, not per-token ITL quantiles. All measured client runs completed with zero reported request failures. Success is not a model-accuracy score.', '',
    '### Observer limitations', '',
    'The old serving observer reads a phase file each adaptive call and writes aggregated JSON every 32 calls. Its reported CPU counter does not include all flush I/O. Overhead was not isolated, so it remains a possible measurement perturbation. Phase labels also include the client’s untimed single-request probe; histogram medians/fractions therefore are NOT timed-window workload distributions. Timed throughput comes from the client’s independent timed interval. Per-rank maxima cannot be summed into simultaneous global concurrency. These limitations do not erase the unfavorable timings.', '',
    '## Correctness and eager limits', '',
    'All reported fixed-shape outputs are finite. Full four-rank numerical receipts are retained. Some larger TP4 and DEP cases differ across repeated unchunked baselines and/or repeated replay of the same graph; no universal final hidden-state or generated-token bit-equivalence claim is made. This does not prove all candidate differences are harmless. See CORRECTNESS_SUMMARY.json. Prior producer score bits, exact top-k score tests, and limited real-text smoke tests are documented in the earlier evidence package, not rerun here.', '',
    'Generated-text string hashes and equality rates are preserved for serving; token IDs were not collected. Random-prompt throughput is not a reasoning/accuracy evaluation. New long-output representative workload correctness/performance remains unmeasured.', '',
    'The new mixed graph/eager runs contain substantial eager baseline drift. Their raw eager samples are retained, but apparent large gains (including the largest DEP shape) are not accepted as causal improvements. The prior dedicated interleaved eager experiment remains separate evidence.', '',
    '## Current decision and missing evidence', '',
    '- Keep PR #64806 draft. Keep the implementation and configurable 2 GiB value unchanged while reviewing the data; do not call 2 GiB optimal or production-validated.',
    '- User priority is normal concurrency with several thousand generated tokens. No new GPU run is started by this consolidation. The canceled 256-output proposals are explicitly not validation.',
    '- Request-count-skewed DEP with real graph padding, stable long-output A/B, and the source of adaptive-serving variation remain open.',
    '- Do not erase extreme-concurrency regressions when normal-workload evidence is eventually added. Conversely, do not extrapolate those regressions to every deployment.', '',
    '## Upstream workload references (research only)', '',
    '[Merged #58466](https://github.com/vllm-project/vllm/pull/58466) uses SPEED-Bench throughput_2k, a 2048-token output cap with natural EOS, and concurrency through 256. It reports boot-to-boot adaptive cost-curve variation and a benchmark-only fixed-curve control. That is a diagnostic lead, not proof of this run’s cause. Natural EOS means the cap is not a guaranteed 2048 generated tokens.', '',
    '[Merged #63886](https://github.com/vllm-project/vllm/pull/63886) tests V4.1 + DSpark on four GB200 GPUs with SPEED-Bench low_entropy/throughput_2k, natural EOS, concurrency 1–256, and AV on/off. Its model settings differ; we have not reproduced it. These references support replacing the proposed 256-output workload, not borrowing their performance conclusions.', '',
    '## Reproduction and receipts', '',
    '- MODEL_RAW.json.gz: complete JSON timing/correctness records and identities for four ranks in all three completed model jobs; no tensor payloads.',
    '- SERVING_RECEIPTS.json.gz: aggregate and per-request numeric results, generated-string hashes, and driver completion records. Full generated text and per-token ITL arrays remain local and are omitted from this compact public package.',
    '- SOURCE_MANIFEST.json: relative source paths, sizes and SHA256 of the source receipts. Large hidden-state .pt files remain local.',
    '- EXPERIMENT_SCRIPTS.tar.gz: executed scripts/configs, identity records, commands, interpretation notes, and the canceled follow-up setup (explicitly labeled). Not a production-code patch.',
    '- Existing source package: [initial completed evidence](https://github.com/Pb314314/vllm/tree/e3a7e2474b3f749854df211fde16febf3f0da4ad/benchmarks/kernels/indexer_chunk/evidence/2026-10-30). Older default recommendations are superseded by the qualification in this report, without overwriting their measurements.', '',
    'AI assistance was used to organize and analyze this evidence. Human review remains pending; this update does not request re-review or mark the PR ready.', '']
(out/'README.md').write_text('\n'.join(lines))
write('SUMMARY.json', dict(production_head='d51f40aeffe014e4ee1f77759b22501893f84d5e',
    models=model_rows, serving=serving_comparisons, correctness=correctness,
    no_new_experiments=True, default_status='provisional'))
with tarfile.open(out/'EXPERIMENT_SCRIPTS.tar.gz', 'w:gz') as tar:
    for stage in ['model','dep_model','dep_imbalance','serve','dep_serve','normal_tp','normal_dep']:
        for pat in ['*.py','*.sh','*.sbatch','*.md','MANIFEST.json','hooks/*.py','model_*/identity_rank*.json','results/*/c*.command.json','results/*/command.argv0']:
            for file in sorted((root/stage).glob(pat)):
                tar.add(file, arcname=str(file.relative_to(root)))
    for name in ['PROTOCOL.md','INTERPRETATION.md','NORMAL_WORKLOAD_PROTOCOL.md','PROGRESS.json']:
        tar.add(root/name,arcname=name)
    tar.add(Path(__file__), arcname='consolidate_completed.py')
print('Wrote',out,'model rows',len(model_rows),'serving comparisons',len(serving_comparisons))
