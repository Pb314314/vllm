# DEP unequal-history sensitivity

DP4 + TP1 + EP4, real V4.1 weights and routing, synthetic tokens, zero historical KV. Production code is unchanged. This extends the completed uniform DEP measurement; it is not an end-to-end or unequal-request-count test.

Every rank has 512 requests with 8 query tokens (7 draft positions), so each rank has 4096 query rows. Global request count is 2048. History lengths by DP rank:

- balanced: 4096 / 4096 / 4096 / 4096
- history_skew: 2048 / 2048 / 4096 / 8192
- history_skew_rotated: 8192 / 4096 / 2048 / 2048

Total effective history positions and query rows are equal across layouts. Rotation helps expose rank/NUMA asymmetry. Both budgets are compared to that layout's own unchunked baseline; do not interpret raw balanced-vs-skew latency as chunk overhead.

Budgets: 0 / 2048 / 4096 / 4096 / 2048 / 0 MiB. Fixed 32 GiB KV per GPU. Each visit has 150 graph samples and 10 eager host-wall samples. Report baseline drift and sample spread. GPU events report rank maximum including model communication, not isolated communication time. Historical KV and repeated model output nondeterminism remain explicit limitations.

The one-shot benchmark bypasses production graph bucket dispatch. Assert 4096 prepared rows on every rank. This test checks unequal K work with equal Q; production DP request padding and adaptive policy must be validated separately in serving. No inference that all uneven DEP workloads pass.
