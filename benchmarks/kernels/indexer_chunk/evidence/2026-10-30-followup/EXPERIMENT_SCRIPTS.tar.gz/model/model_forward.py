import faulthandler
import signal
import argparse
import gc
import hashlib
import json
import os
import time
import statistics
from pathlib import Path

import torch
from vllm.benchmarks.forward import main as bm
from vllm.benchmarks.forward.capture import ForwardBench, _first_tensor
from vllm.benchmarks.forward.shapes import jitter_kv_lens, parse_case
from vllm.config import set_current_vllm_config
from vllm.utils.argparse_utils import FlexibleArgumentParser
import vllm.envs as envs
import vllm.model_executor.layers.sparse_attn_indexer as idx
import vllm._C_stable_libtorch as native

p = FlexibleArgumentParser()
bm.add_cli_args(p)
p.add_argument('--experiment-dir', required=True)
args = p.parse_args()
out = Path(args.experiment_dir)
out.mkdir(parents=True, exist_ok=True)
assert hashlib.sha256(Path(native.__file__).read_bytes()).hexdigest() == 'f96b1e72533bc79d154f245d0ffc62817fd99fd2987e97b8e4e63a14dbe02f92'
cases = [parse_case(c) for c in args.case]
bm._setup_env()
from vllm import LLM
from vllm.distributed.parallel_state import get_world_group
llm = LLM.from_engine_args(bm._make_engine_args(args, cases))
runner = llm.llm_engine.model_executor.driver_worker.worker.model_runner
world = get_world_group()
stack_file=(out/f'stack_rank{world.rank}.log').open('w')
faulthandler.register(signal.SIGUSR1,file=stack_file,all_threads=True)
print('FAULT_HANDLER_READY',world.rank,os.getpid(),flush=True)
cases = [jitter_kv_lens(c, args.kv_len_jitter, runner.model_config.max_model_len, args.seed) for c in cases]
# Benchmark-only: change this setting only between destroyed graphs, with the
# same loaded model and fixed KV allocation. This does not measure startup/KV gain.
envs.disable_envs_cache()
old_plan = idx._decode_chunk_ranges
plans = []
def plan(*a, **kw):
    result = old_plan(*a, **kw)
    plans.append(dict(rows=a[0], width=a[1], budget=a[2], chunks=result))
    return result
idx._decode_chunk_ranges = plan
old_capture = ForwardBench._capture_and_time
old_time = ForwardBench._time
hidden = None

def time_graph(self, graph):
    print('STAGE',world.rank,self.name,'graph-time',flush=True)
    result = old_time(self, graph)
    pool = tuple(graph.pool())
    segments = [x for x in torch.cuda.memory_snapshot() if tuple(x.get('segment_pool_id', x.get('owner_private_pool_id', (0, 0)))) == pool]
    self.result['graph_private_reserved_bytes'] = sum(x['total_size'] for x in segments)
    return result


def capture(self):
    global hidden
    print('STAGE',world.rank,self.name,'capture-enter',flush=True)
    snapshots = [(v, v.clone()) for v in self.state_views]
    def restore():
        for v, saved in snapshots:
            v.copy_(saved)
    for warm in range(3):
        print('STAGE',world.rank,self.name,'eager-warm',warm,flush=True)
        restore()
        torch.cuda.synchronize()
        torch.distributed.barrier(group=world.cpu_group)
        self._run_model()
    samples = []
    for sample in range(20):
        if sample in (0,19):print('STAGE',world.rank,self.name,'eager-time',sample,flush=True)
        restore()
        torch.distributed.barrier(group=world.device_group)
        torch.cuda.synchronize()
        start = time.perf_counter_ns()
        self._run_model()
        torch.cuda.synchronize()
        samples.append((time.perf_counter_ns() - start) / 1000)
    elapsed = torch.tensor(samples, device=self.device)
    torch.distributed.all_reduce(elapsed, op=torch.distributed.ReduceOp.MAX, group=world.device_group)
    self.result['eager_host_wall_us'] = elapsed.cpu().tolist()
    restore()
    del snapshots
    # Indexer-only host bound matches production FULL capture. Other attention
    # metadata remains the exact-shape benchmark's metadata; this is not serving.
    from vllm.forward_context import get_forward_context
    from vllm.v1.attention.backends.mla.indexer import DeepseekV32IndexerMetadata
    metadata = get_forward_context().attn_metadata
    changed = []
    seen = set()
    if isinstance(metadata, dict):
        for item in metadata.values():
            if isinstance(item, DeepseekV32IndexerMetadata) and id(item) not in seen:
                seen.add(id(item))
                changed.append((item, item.max_seq_len))
                item.max_seq_len = runner.model_config.max_model_len
    self.result['indexer_graph_host_bound'] = runner.model_config.max_model_len
    self.result['indexer_metadata_count'] = len(changed)
    assert changed, 'No indexer metadata was adjusted; FULL-bound control not exercised'
    try:
        print('STAGE',world.rank,self.name,'original-capture-enter',flush=True)
        value = old_capture(self)
        hidden = _first_tensor(value).detach().cpu().clone()
        self.result['cuda_allocated_after_bytes'] = torch.cuda.memory_allocated()
        self.result['cuda_reserved_after_bytes'] = torch.cuda.memory_reserved()
        return value
    finally:
        for item, bound in changed:
            item.max_seq_len = bound

ForwardBench._time = time_graph
ForwardBench._capture_and_time = capture
identity = dict(native_sha=hashlib.sha256(Path(native.__file__).read_bytes()).hexdigest(), caller_sha=hashlib.sha256(Path(idx.__file__).read_bytes()).hexdigest(), argv=vars(args), rank=world.rank, device=str(torch.cuda.get_device_properties(0)), scope='FIXED-SHAPE sensitivity, adaptive manager disabled; real weights, real routing, synthetic tokens, zero historical KV; target-only; graph uses max-model-length indexer host bound, other attention metadata exact-shape. Eager uses actual bounds; rank-max synchronized host wall excludes state reset and barrier. Graph GPU event time excludes state reset/barrier. Fixed KV allocation across budgets; not serving.')
(out/f'identity_rank{world.rank}.json').write_text(json.dumps(identity, indent=2, default=str))
records = []
with torch.inference_mode(), set_current_vllm_config(runner.vllm_config):
    for case in cases:
        reference = None
        for trial, budget in enumerate([0, 2048, 4096, 4096, 2048, 0]):
            os.environ['VLLM_SPARSE_INDEXER_MAX_DECODE_LOGITS_MB'] = str(budget)
            assert envs.VLLM_SPARSE_INDEXER_MAX_DECODE_LOGITS_MB == budget
            plans.clear()
            gc.collect()
            torch.cuda.empty_cache()
            torch.cuda.reset_peak_memory_stats()
            print('STAGE',world.rank,case.name,budget,'run-case',flush=True)
            result = bm.run_case(runner, case, args)
            assert result['finite'], (case.name, budget, 'nonfinite')
            if reference is None:
                reference = hidden.clone()
            delta = (hidden.float()-reference.float())
            result['vs_no_chunk_hidden'] = dict(bits_equal=torch.equal(hidden.view(torch.int16), reference.view(torch.int16)), max_abs=delta.abs().max().item(), relative_rms=(delta.square().mean().sqrt()/reference.float().square().mean().sqrt().clamp_min(1e-12)).item())
            torch.save(hidden, out / f'{case.name}_trial{trial}_budget{budget}_rank{world.rank}.pt')
            unique = {json.dumps(x, sort_keys=True):x for x in plans}
            result['observed_plans'] = list(unique.values())
            result['peak_allocated_bytes'] = torch.cuda.max_memory_allocated()
            record = dict(case=case.name, requests=[vars(r) for r in case.requests], budget_MiB=budget, trial=trial, result=result)
            records.append(record)
            (out/f'RESULT_rank{world.rank}.json').write_text(json.dumps(dict(status='partial', records=records), indent=2))
            if world.rank == 0:
                print('MEASURED', case.name, budget, result['latency_us']['median'], result['vs_no_chunk_hidden'], result['observed_plans'], flush=True)
(out/f'RESULT_rank{world.rank}.json').write_text(json.dumps(dict(status='complete', records=records), indent=2))
