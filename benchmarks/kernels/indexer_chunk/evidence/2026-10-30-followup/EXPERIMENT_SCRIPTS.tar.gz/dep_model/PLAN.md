# Single-node DEP validation

User-confirmed topology: attention DP4, TP1, MoE EP4 on four GB200 GPUs in one node. Same frozen PR2 runtime and native binary as the TP4+EP comparison. No production code changes.

Fixed-shape target-forward matrix: per-DP-rank256x8@8K,512x8@8K,1024x8@4K, respectively2048/4096/8192 query rows per rank and1024/2048/4096 requests globally. Real weights and real routing; synthetic query tokens, zero historical KV. Uniform shapes across DP ranks are a controlled sensitivity test, not uneven production load. Adaptive and drafter disabled for this isolated target-forward test. Budgets0/2048/4096/4096/2048/0 MiB. Rank-max graph timing150 replays per visit; eager10 synchronized host samples per visit. Same32 GiB KV allocation per GPU. Initial synthetic profile uses2 GiB, actual comparison changes only after destroyed graphs. Check actual DP/TP/EP group sizes at runtime.

Follow-up serving must use actual DP routing and adaptive verification, record each DP rank separately, and compare throughput and tail latency against repeated unchunked baselines. TP replicas must not be confused with distinct DP batches. Report peak memory per GPU and the slowest rank; do not extrapolate TP4 results or average away a regression on a rank.

Acceptance: user asks for minimal DEP performance loss; no numeric cutoff has been supplied. Publish the measured regression with baseline variation and memory saved rather than invent a pass threshold. If2 GiB has a reproducible material regression, compare4 GiB and retain configurability rather than call the smaller budget universally best.
