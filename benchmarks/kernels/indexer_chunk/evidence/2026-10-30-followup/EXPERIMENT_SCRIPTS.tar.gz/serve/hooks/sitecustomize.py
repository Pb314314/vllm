"""Benchmark-only CPU observations; never read a GPU tensor or change decisions."""
import collections
import hashlib
import json
import os
import time
from pathlib import Path

if os.environ.get('CHUNK_ADAPTIVE_TRACE'):
    import torch
    import vllm.envs as envs
    import vllm._C_stable_libtorch as native
    import vllm.model_executor.layers.sparse_attn_indexer as idx
    from vllm.v1.worker.gpu.spec_decode.adaptive_verification import AdaptiveVerificationManager as Manager
    from vllm.v1.worker.gpu_worker import Worker
    out = Path(os.environ['CHUNK_ADAPTIVE_TRACE'])
    out.mkdir(parents=True, exist_ok=True)
    assert hashlib.sha256(Path(native.__file__).read_bytes()).hexdigest() == 'f96b1e72533bc79d154f245d0ffc62817fd99fd2987e97b8e4e63a14dbe02f92'
    phases = {}
    graphs = {}
    active = None
    current_phase = 'startup'
    calls = 0
    extra_ns = 0
    original_memory = Worker.determine_available_memory
    def memory(self, *a, **kw):
        # Equal fixed KV in both timing arms. Bound only the synthetic profile
        # allocation; actual target capture and execution use the selected arm.
        assert self.cache_config.kv_cache_memory_bytes == 17179869184
        budget = os.environ['VLLM_SPARSE_INDEXER_MAX_DECODE_LOGITS_MB']
        envs.disable_envs_cache()
        os.environ['VLLM_SPARSE_INDEXER_MAX_DECODE_LOGITS_MB'] = '2048'
        try:
            return original_memory(self, *a, **kw)
        finally:
            os.environ['VLLM_SPARSE_INDEXER_MAX_DECODE_LOGITS_MB'] = budget
            envs.disable_envs_cache()
    Worker.determine_available_memory = memory
    def flush():
        value = dict(pid=os.getpid(),budget=os.environ['VLLM_SPARSE_INDEXER_MAX_DECODE_LOGITS_MB'],phases=phases,graphs=graphs,observer_cpu_ns=extra_ns,adaptive_calls=calls)
        tmp = out / f'{os.getpid()}.tmp'
        tmp.write_text(json.dumps(value))
        tmp.replace(out / f'{os.getpid()}.json')
    def phase():
        try:return Path(os.environ['CHUNK_ADAPTIVE_PHASE']).read_text().strip()
        except FileNotFoundError:return 'startup'
    original_get = Manager.get_num_tokens
    def get(self, tokens, drafts):
        global current_phase,calls,extra_ns
        value = original_get(self,tokens,drafts)
        t = time.perf_counter_ns()
        new_phase = phase()
        if new_phase != current_phase:
            flush()
            current_phase = new_phase
        stat = phases.setdefault(current_phase,dict(adaptive={},replays={}))
        capacity, non_drafts, admitted = self._batch_budget
        key = f'{len(tokens)}/{sum(tokens.values())}/{int(value)}/{sum(capacity.values())}/{admitted}'
        stat['adaptive'][key] = stat['adaptive'].get(key,0)+1
        calls += 1
        extra_ns += time.perf_counter_ns()-t
        if calls % 32 == 0:flush()
        return value
    Manager.get_num_tokens = get
    original_begin = torch.cuda.CUDAGraph.capture_begin
    original_end = torch.cuda.CUDAGraph.capture_end
    original_replay = torch.cuda.CUDAGraph.replay
    original_logits = idx.fp8_fp4_paged_mqa_logits
    def begin(graph,*a,**kw):
        global active
        active=str(id(graph));graphs[active]=[]
        return original_begin(graph,*a,**kw)
    def end(graph,*a,**kw):
        global active
        result=original_end(graph,*a,**kw);active=None
        return result
    def logits(*a,**kw):
        if active is not None and torch.cuda.is_current_stream_capturing():
            graphs[active].append(dict(q_shape=list(a[0][0].shape),width=kw.get('max_model_len')))
        return original_logits(*a,**kw)
    def replay(graph,*a,**kw):
        result=original_replay(graph,*a,**kw)
        gid=str(id(graph))
        if graphs.get(gid):
            stat=phases.setdefault(current_phase,dict(adaptive={},replays={}))
            stat['replays'][gid]=stat['replays'].get(gid,0)+1
        return result
    torch.cuda.CUDAGraph.capture_begin=begin
    torch.cuda.CUDAGraph.capture_end=end
    torch.cuda.CUDAGraph.replay=replay
    idx.fp8_fp4_paged_mqa_logits=logits
