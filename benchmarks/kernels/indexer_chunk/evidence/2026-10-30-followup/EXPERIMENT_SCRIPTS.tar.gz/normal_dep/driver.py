"""Owned-node A/B/A serving test; no unrelated GPU process may be stopped."""
import json,os,signal,socket,subprocess,sys,time,urllib.request
from pathlib import Path
here=Path(__file__).resolve().parent
variant,folder=sys.argv[1:];assert variant in ['A','B']
out=Path(folder);out.mkdir(parents=True,exist_ok=False)
server=None
status=dict(variant=variant,started=time.time(),complete=False,hostname=socket.gethostname(),allocation=os.environ.get('SLURM_JOB_ID'),clients=[])
py='/home/bopang/cg-project/design/indexer-bf16-native-research-20261028/minimal_pr1_20261029/model_runtime_preparation_v1/pd_venv_v1/bin/python'
runtime='/home/bopang/cg-project/design/indexer-chunk-default-20261030-v2/refinement/runtime'
model='/mnt/lustre/hf-models/hub/models--deepseek-ai--DeepSeek-V4.1-Flash/snapshots/2cba9e42aa026125f3ed06c6d98c1db82f7ca027'
def metrics(name):
    with urllib.request.urlopen('http://127.0.0.1:8200/metrics',timeout=20) as r:
        (out/f'{name}.metrics.txt').write_bytes(r.read())
def bench(name,concurrency,isl,osl,count,seed):
    (out/'PHASE').write_text(name)
    metrics(name+'.before')
    cmd=[py,'-m','vllm.entrypoints.cli.main','bench','serve','--backend','vllm','--base-url','http://127.0.0.1:8200','--endpoint','/v1/completions','--model',model,'--served-model-name','deepseek-ai/DeepSeek-V4.1-Flash','--tokenizer',model,'--tokenizer-mode','deepseek_v41','--trust-remote-code','--dataset-name','random','--random-input-len',str(isl),'--random-output-len',str(osl),'--random-range-ratio','0','--num-prompts',str(count),'--max-concurrency',str(concurrency),'--request-rate','inf','--ignore-eos','--temperature','0','--seed',str(seed),'--disable-tqdm','--ready-check-timeout-sec','0','--save-result','--save-detailed','--result-dir',str(out),'--result-filename',name+'.json']
    (out/f'{name}.command.json').write_text(json.dumps(cmd,indent=2)+'\n')
    env=dict(os.environ,PYTHONPATH=runtime,HF_HUB_OFFLINE='1',TOKENIZERS_PARALLELISM='false')
    with (out/f'{name}.log').open('w') as log:
        result=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1500)
    assert result.returncode==0,(name,result.returncode)
    data=json.loads((out/f'{name}.json').read_text());assert data['completed']==count,(name,data.get('completed'),count)
    assert not any(data.get('errors',[])),name
    metrics(name+'.after')
    status['clients'].append(dict(name=name,concurrency=concurrency,input_tokens=isl,output_tokens=osl,count=count,completed=data['completed'],output_throughput=data['output_throughput']))
    (out/'DRIVER.partial.json').write_text(json.dumps(status,indent=2)+'\n')
    print('BENCH_COMPLETE',variant,name,data['output_throughput'],flush=True)
try:
    deadline=time.monotonic()+120
    while subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip():
        if time.monotonic()>deadline:raise RuntimeError('Pre-existing GPU work; refusing to start')
        time.sleep(5)
    with (out/'server.log').open('w') as log:
        server=subprocess.Popen(['bash',str(here/'role.sh'),variant,str(out)],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        deadline=time.monotonic()+2700
        while True:
            if server.poll() is not None:raise RuntimeError(f'Server exited{server.returncode} before health')
            try:
                with urllib.request.urlopen('http://127.0.0.1:8200/health',timeout=2) as r:
                    if r.status==200:break
            except Exception:pass
            if time.monotonic()>deadline:raise TimeoutError('45-minute readiness deadline')
            time.sleep(2)
        status['ready']=time.time()
        bench('smoke',8,128,32,8,1741)
        for concurrency,isl,osl in [(128,4096,256),(512,4096,256),(256,16384,256)]:
            bench(f'warm_c{concurrency}_i{isl}',concurrency,isl,64,concurrency,1740)
            for repeat in range(2):
                bench(f'c{concurrency}_i{isl}_r{repeat}',concurrency,isl,osl,2*concurrency,1741)
        bench('flush',8,128,32,8,1742)
        status['complete']=True
finally:
    if server is not None:
        try:os.killpg(server.pid,signal.SIGTERM)
        except ProcessLookupError:pass
        try:server.wait(timeout=30)
        except subprocess.TimeoutExpired:
            os.killpg(server.pid,signal.SIGKILL);server.wait(timeout=10)
    status['ended']=time.time()
    (out/'DRIVER.json').write_text(json.dumps(status,indent=2)+'\n')
