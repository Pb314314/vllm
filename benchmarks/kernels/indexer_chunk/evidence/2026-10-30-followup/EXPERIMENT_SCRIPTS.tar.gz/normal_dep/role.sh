#!/usr/bin/env bash
# Controlled single-node DEP serving comparison; owned allocation.
set -euo pipefail
variant=$1
output=$2
[[ $variant == A || $variant == B ]] || exit 2
here=$(cd "$(dirname "$0")" && pwd)
base=$(dirname "$here")
runtime=/home/bopang/cg-project/design/indexer-chunk-default-20261030-v2/refinement/runtime
python=/home/bopang/cg-project/design/indexer-bf16-native-research-20261028/minimal_pr1_20261029/model_runtime_preparation_v1/pd_venv_v1/bin/python
mkdir -p "$output"
export PYTHONPATH="$here/hooks:$runtime" PYTHONDONTWRITEBYTECODE=1
export CUDA_VISIBLE_DEVICES=0,1,2,3
export CUDA_HOME=/usr/local/cuda-13.1 CUDA_PATH=/usr/local/cuda-13.1
export PATH="$(dirname "$python"):/home/bopang/vllm/.venv/bin:/home/bopang/cg-project/venv-b4a0fix/bin:/usr/local/cuda-13.1/bin:/usr/bin:/bin"
export DG_JIT_NVCC_COMPILER=/usr/local/cuda-13.1/bin/nvcc
export DJ_JIT_NVCC_COMPILER=/usr/local/cuda-13.1/bin/nvcc
export HF_HOME=/home/bopang/cg-project/design/idx-breakdown-cache/pd-env/hf
export HF_HUB_CACHE="$HF_HOME/hub" HF_HUB_OFFLINE=1
export VLLM_USE_V2_MODEL_RUNNER=1 VLLM_USE_RUST_FRONTEND=0
export VLLM_ENGINE_READY_TIMEOUT_S=2700
export VLLM_CACHE_ROOT="/home/bopang/cg-project/design/indexer-chunk-adaptive-20261030-v1/dep_serve/cache/vllm"
export DG_JIT_CACHE_DIR="/home/bopang/cg-project/design/indexer-chunk-adaptive-20261030-v1/dep_serve/cache/deep_gemm" JIT_CACHE_DIR="/home/bopang/cg-project/design/indexer-chunk-adaptive-20261030-v1/dep_serve/cache/deep_gemm"
export TRITON_CACHE_DIR="/home/bopang/cg-project/design/indexer-chunk-adaptive-20261030-v1/dep_serve/cache/triton"
export FLASHINFER_WORKSPACE_BASE="/home/bopang/cg-project/design/indexer-chunk-adaptive-20261030-v1/dep_serve/cache/flashinfer"
export FLASHINFER_AUTOTUNE_CACHE_DIR="/home/bopang/cg-project/design/indexer-chunk-adaptive-20261030-v1/dep_serve/cache/flashinfer_autotune"
unset CHUNK_ADAPTIVE_TRACE CHUNK_ADAPTIVE_PHASE
export CHUNK_NORMAL_STARTUP_CONTROL=1

CAST_E2E_NATIVE_SHA=$(sha256sum "$runtime/vllm/_C_stable_libtorch.abi3.so" | cut -d' ' -f1)
export CAST_E2E_NATIVE_SHA
expected=f96b1e72533bc79d154f245d0ffc62817fd99fd2987e97b8e4e63a14dbe02f92
[[ $CAST_E2E_NATIVE_SHA == "$expected" ]] || exit 2
if [[ $variant == A ]]; then export VLLM_SPARSE_INDEXER_MAX_DECODE_LOGITS_MB=0; else export VLLM_SPARSE_INDEXER_MAX_DECODE_LOGITS_MB=2048; fi
export VLLM_DEEP_GEMM_WARMUP=skip
args=(--host 127.0.0.1 --port 8200 --served-model-name deepseek-ai/DeepSeek-V4.1-Flash
 --tokenizer-mode deepseek_v41 --trust-remote-code
 --revision 2cba9e42aa026125f3ed06c6d98c1db82f7ca027
 --tokenizer-revision 2cba9e42aa026125f3ed06c6d98c1db82f7ca027
 --max-model-len 1048576 --max-num-seqs 1024 --max-num-batched-tokens 8192
 --gpu-memory-utilization 0.85 --kv-cache-memory-bytes 17179869184 --no-enable-prefix-caching --tensor-parallel-size 1 --data-parallel-size 4 --enable-expert-parallel
 --decode-context-parallel-size 1 --kv-cache-dtype fp8 --block-size 128
 --language-model-only --mm-encoder-tp-mode data --attention-config '{"backend":"FLASHINFER_MLA_SPARSE_DSV41","indexer_kv_dtype":"mxfp4","indexer_sparse_logits":true}'
 --speculative-config '{"method":"dspark","revision":"2cba9e42aa026125f3ed06c6d98c1db82f7ca027","num_speculative_tokens":7,"enable_adaptive_verification":true}'
 --kernel-config '{"sparse_indexer_topk_backend":"auto","enable_jit_warmup":false,"enable_cutedsl_warmup":false,"enable_flashinfer_autotune":false}'
 --compilation-config '{"cudagraph_mode":"FULL_DECODE_ONLY","cudagraph_capture_sizes":[8,128,256,512,1024,2048,4096,8192]}' --no-numa-bind --seed 0)
model="/mnt/lustre/hf-models/hub/models--deepseek-ai--DeepSeek-V4.1-Flash/snapshots/2cba9e42aa026125f3ed06c6d98c1db82f7ca027"
printf '%s\0' "$python" -m vllm.entrypoints.cli.main serve "$model" "${args[@]}" > "$output/command.argv0"
echo $$ > "$output/server_pid.txt"
cd /tmp
exec "$python" -m vllm.entrypoints.cli.main serve "$model" "${args[@]}"
