"""Benchmark-only fixed-KV startup control; no steady-state instrumentation."""
import os
if os.environ.get('CHUNK_NORMAL_STARTUP_CONTROL') == '1':
    import hashlib
    from pathlib import Path
    import vllm.envs as envs
    import vllm._C_stable_libtorch as native
    from vllm.v1.worker.gpu_worker import Worker
    assert hashlib.sha256(Path(native.__file__).read_bytes()).hexdigest() == 'f96b1e72533bc79d154f245d0ffc62817fd99fd2987e97b8e4e63a14dbe02f92'
    original_memory = Worker.determine_available_memory
    def memory(self, *a, **kw):
        assert self.cache_config.kv_cache_memory_bytes == 17179869184
        budget = os.environ['VLLM_SPARSE_INDEXER_MAX_DECODE_LOGITS_MB']
        envs.disable_envs_cache()
        os.environ['VLLM_SPARSE_INDEXER_MAX_DECODE_LOGITS_MB'] = '2048'
        try:
            return original_memory(self, *a, **kw)
        finally:
            os.environ['VLLM_SPARSE_INDEXER_MAX_DECODE_LOGITS_MB'] = budget
            envs.disable_envs_cache()
            print('CHUNK_NORMAL_PROFILE_RESTORED', os.getpid(), budget, flush=True)
    Worker.determine_available_memory = memory
